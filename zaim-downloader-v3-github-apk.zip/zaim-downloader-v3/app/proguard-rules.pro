# Keep Room generated implementations and OkHttp internals.
-keep class androidx.room.** { *; }
-keep class com.zaim.downloader.data.db.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
