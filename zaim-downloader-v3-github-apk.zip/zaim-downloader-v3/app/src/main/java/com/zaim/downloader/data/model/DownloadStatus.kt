package com.zaim.downloader.data.model

/** Lifecycle of a single download. Stored in Room as its [name]. */
enum class DownloadStatus {
    QUEUED,
    ANALYZING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED;

    val isActive: Boolean
        get() = this == QUEUED || this == ANALYZING || this == DOWNLOADING

    val isFinished: Boolean
        get() = this == COMPLETED || this == FAILED || this == CANCELLED

    companion object {
        fun fromName(value: String?): DownloadStatus =
            values().firstOrNull { it.name == value } ?: QUEUED
    }
}
