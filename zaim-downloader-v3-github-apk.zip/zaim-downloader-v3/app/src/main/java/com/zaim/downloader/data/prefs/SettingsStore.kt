package com.zaim.downloader.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "zaim_settings")

enum class ThemeMode { DARK, LIGHT, SYSTEM }
enum class LanguageMode { AR, EN, SYSTEM }

/** Everything the Settings screen can change. */
data class AppSettings(
    val defaultKind: String = "VIDEO",
    val defaultQuality: String = "720p",
    val downloadFolder: String = "ZAIM Downloader",
    val maxParallel: Int = 3,
    val segmented: Boolean = true,
    val floatingEnabled: Boolean = false,
    val notificationsEnabled: Boolean = true,
    val theme: ThemeMode = ThemeMode.DARK,
    val language: LanguageMode = LanguageMode.SYSTEM
)

class SettingsStore(private val context: Context) {

    private object Keys {
        val DEFAULT_KIND = stringPreferencesKey("default_kind")
        val DEFAULT_QUALITY = stringPreferencesKey("default_quality")
        val DOWNLOAD_FOLDER = stringPreferencesKey("download_folder")
        val MAX_PARALLEL = intPreferencesKey("max_parallel")
        val SEGMENTED = booleanPreferencesKey("segmented")
        val FLOATING_ENABLED = booleanPreferencesKey("floating_enabled")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { p ->
        AppSettings(
            defaultKind = p[Keys.DEFAULT_KIND] ?: "VIDEO",
            defaultQuality = p[Keys.DEFAULT_QUALITY] ?: "720p",
            downloadFolder = p[Keys.DOWNLOAD_FOLDER] ?: "ZAIM Downloader",
            maxParallel = p[Keys.MAX_PARALLEL] ?: 3,
            segmented = p[Keys.SEGMENTED] ?: true,
            floatingEnabled = p[Keys.FLOATING_ENABLED] ?: false,
            notificationsEnabled = p[Keys.NOTIFICATIONS_ENABLED] ?: true,
            theme = runCatching { ThemeMode.valueOf(p[Keys.THEME] ?: ThemeMode.DARK.name) }
                .getOrDefault(ThemeMode.DARK),
            language = runCatching { LanguageMode.valueOf(p[Keys.LANGUAGE] ?: LanguageMode.SYSTEM.name) }
                .getOrDefault(LanguageMode.SYSTEM)
        )
    }

    suspend fun setDefaultKind(value: String) = edit { it[Keys.DEFAULT_KIND] = value }
    suspend fun setDefaultQuality(value: String) = edit { it[Keys.DEFAULT_QUALITY] = value }
    suspend fun setDownloadFolder(value: String) = edit { it[Keys.DOWNLOAD_FOLDER] = value }
    suspend fun setMaxParallel(value: Int) = edit { it[Keys.MAX_PARALLEL] = value.coerceIn(1, 5) }
    suspend fun setSegmented(value: Boolean) = edit { it[Keys.SEGMENTED] = value }
    suspend fun setFloatingEnabled(value: Boolean) = edit { it[Keys.FLOATING_ENABLED] = value }
    suspend fun setNotificationsEnabled(value: Boolean) = edit { it[Keys.NOTIFICATIONS_ENABLED] = value }
    suspend fun setTheme(value: ThemeMode) = edit { it[Keys.THEME] = value.name }
    suspend fun setLanguage(value: LanguageMode) = edit { it[Keys.LANGUAGE] = value.name }

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        context.settingsDataStore.edit(block)
    }
}
