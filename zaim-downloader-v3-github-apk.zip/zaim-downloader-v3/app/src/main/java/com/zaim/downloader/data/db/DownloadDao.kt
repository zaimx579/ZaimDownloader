package com.zaim.downloader.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.zaim.downloader.data.model.DownloadItem
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadItem>>

    @Query(
        "SELECT * FROM downloads WHERE status IN ('QUEUED','ANALYZING','DOWNLOADING','PAUSED') " +
            "ORDER BY createdAt DESC"
    )
    fun observeActive(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE status = 'COMPLETED' ORDER BY completedAt DESC")
    fun observeCompleted(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE status IN ('FAILED','CANCELLED') ORDER BY updatedAt DESC")
    fun observeFailed(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun findById(id: Long): DownloadItem?

    /** Duplicate guard: the same link already queued, running or finished. */
    @Query(
        "SELECT * FROM downloads WHERE sourceUrl = :url " +
            "AND status IN ('QUEUED','ANALYZING','DOWNLOADING','PAUSED','COMPLETED') LIMIT 1"
    )
    suspend fun findExisting(url: String): DownloadItem?

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED','ANALYZING','DOWNLOADING') ORDER BY createdAt ASC")
    suspend fun activeItems(): List<DownloadItem>

    @Query("SELECT COUNT(*) FROM downloads WHERE status IN ('QUEUED','ANALYZING','DOWNLOADING')")
    suspend fun activeCount(): Int

    @Insert
    suspend fun insert(item: DownloadItem): Long

    @Update
    suspend fun update(item: DownloadItem)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM downloads WHERE status IN ('COMPLETED','FAILED','CANCELLED')")
    suspend fun clearFinished()
}
