package com.zaim.downloader.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.zaim.downloader.MainActivity
import com.zaim.downloader.R

/** Builds every notification the app shows, and owns the two channels. */
class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_DOWNLOADS = "zaim_downloads"
        const val CHANNEL_FLOATING = "zaim_floating"

        const val ID_FLOATING = 1001
        const val ID_DOWNLOAD_BASE = 2000
    }

    private val manager = NotificationManagerCompat.from(context)

    fun ensureChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val system = context.getSystemService(NotificationManager::class.java) ?: return

        system.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DOWNLOADS,
                context.getString(R.string.notif_channel_downloads),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.notif_channel_downloads_desc)
                setShowBadge(false)
            }
        )

        system.createNotificationChannel(
            NotificationChannel(
                CHANNEL_FLOATING,
                context.getString(R.string.notif_channel_floating),
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = context.getString(R.string.notif_channel_floating_desc)
                setShowBadge(false)
            }
        )
    }

    private fun openAppIntent(): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Progress notification for one download. */
    fun buildProgress(
        title: String,
        percent: Int,
        speedText: String,
        remainingText: String,
        indeterminate: Boolean
    ): Notification {
        val text = if (indeterminate) speedText else "$percent% · $speedText · $remainingText"
        return NotificationCompat.Builder(context, CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(100, percent.coerceIn(0, 100), indeterminate)
            .build()
    }

    fun buildComplete(title: String): Notification =
        NotificationCompat.Builder(context, CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification_download)
            .setContentTitle(context.getString(R.string.notif_complete))
            .setContentText(title)
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

    fun buildFailed(title: String, reason: String): Notification =
        NotificationCompat.Builder(context, CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification_download)
            .setContentTitle(context.getString(R.string.notif_failed))
            .setContentText("$title — $reason")
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

    /** Quiet, ongoing notification that keeps the overlay service alive. */
    fun buildFloating(): Notification =
        NotificationCompat.Builder(context, CHANNEL_FLOATING)
            .setSmallIcon(R.drawable.ic_notification_download)
            .setContentTitle(context.getString(R.string.notif_floating_active))
            .setContentText(context.getString(R.string.notif_floating_active_desc))
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    fun notify(id: Int, notification: Notification) {
        if (!manager.areNotificationsEnabled()) return
        runCatching { manager.notify(id, notification) }
    }

    fun cancel(id: Int) = runCatching { manager.cancel(id) }.let { }
}
