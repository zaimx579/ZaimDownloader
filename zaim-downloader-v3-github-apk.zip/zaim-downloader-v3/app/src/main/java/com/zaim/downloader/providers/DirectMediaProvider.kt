package com.zaim.downloader.providers

import com.zaim.downloader.data.model.MediaFormat
import com.zaim.downloader.data.model.MediaKind
import com.zaim.downloader.data.model.Platform
import com.zaim.downloader.utils.UrlUtils
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Handles links that point straight at a media file.
 *
 * This is the one case where a download is unambiguously authorised: the URL
 * itself is the file, so the app only has to confirm it is reachable and read
 * its real size and type from the server's own headers. Nothing is guessed.
 */
class DirectMediaProvider(
    private val client: OkHttpClient,
    override val platform: Platform = Platform.GENERIC
) : MediaProvider {

    override fun canHandle(url: String): Boolean = UrlUtils.looksLikeDirectMedia(url)

    override suspend fun resolve(url: String): ResolveResult {
        if (!UrlUtils.isValid(url)) return ResolveResult.failed(ResolveFailure.INVALID_URL)

        val head = try {
            client.newCall(
                Request.Builder().url(url).head().build()
            ).execute()
        } catch (e: UnknownHostException) {
            return ResolveResult.failed(ResolveFailure.NO_NETWORK)
        } catch (e: SocketTimeoutException) {
            return ResolveResult.failed(ResolveFailure.SERVER_UNAVAILABLE)
        } catch (e: IOException) {
            return ResolveResult.failed(ResolveFailure.SERVER_UNAVAILABLE)
        }

        head.use { response ->
            if (!response.isSuccessful) {
                return when (response.code) {
                    401, 403 -> ResolveResult.failed(ResolveFailure.PROTECTED_MEDIA)
                    404, 410 -> ResolveResult.failed(ResolveFailure.EXPIRED_LINK)
                    in 500..599 -> ResolveResult.failed(ResolveFailure.SERVER_UNAVAILABLE)
                    else -> ResolveResult.failed(ResolveFailure.UNSUPPORTED_FORMAT)
                }
            }

            val contentType = response.header("Content-Type").orEmpty().lowercase()
            val length = response.header("Content-Length")?.toLongOrNull()
            val ranges = response.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true

            val isAudio = contentType.startsWith("audio/")
            val isVideo = contentType.startsWith("video/")
            val isOctet = contentType.startsWith("application/octet-stream")

            if (!isAudio && !isVideo && !isOctet) {
                // An HTML page, a JSON error, a redirect to a player: not a file.
                return ResolveResult.failed(ResolveFailure.UNSUPPORTED_FORMAT)
            }

            val extension = UrlUtils.fileNameFrom(url, if (isAudio) "m4a" else "mp4")
                .substringAfterLast('.', if (isAudio) "m4a" else "mp4")

            val format = MediaFormat(
                id = "direct",
                kind = if (isAudio) MediaKind.AUDIO else MediaKind.VIDEO,
                label = if (isAudio) "Original audio" else "Original quality",
                container = extension,
                url = url,
                sizeBytes = length,
                requiresMux = false
            )

            val note = if (ranges) null else "This server does not support resuming, so the download runs as a single stream."

            return ResolveResult(
                title = UrlUtils.fileNameFrom(url, extension),
                formats = listOf(format),
                note = note
            )
        }
    }
}
