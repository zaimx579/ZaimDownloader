package com.zaim.downloader.providers

import com.zaim.downloader.data.model.Platform
import com.zaim.downloader.utils.UrlUtils
import okhttp3.OkHttpClient

/**
 * Picks the right adapter for a link and resolves it.
 *
 * Order matters: a direct media URL is checked first, because a link that ends
 * in `.mp4` on a social host is still a file the user may legitimately fetch.
 */
class ProviderRegistry(client: OkHttpClient) {

    private val direct = DirectMediaProvider(client)

    private val platformProviders: Map<Platform, MediaProvider> = mapOf(
        Platform.YOUTUBE to PlatformProvider(
            Platform.YOUTUBE,
            "YouTube does not provide a public download endpoint. Use YouTube Premium's " +
                "offline feature, or the creator's own download link if they published one."
        ),
        Platform.TIKTOK to PlatformProvider(
            Platform.TIKTOK,
            "TikTok does not provide a public download endpoint for third-party apps. " +
                "Use the Save video option inside TikTok when the creator allows it."
        ),
        Platform.FACEBOOK to PlatformProvider(
            Platform.FACEBOOK,
            "Facebook serves video through an authenticated pipeline. Use the Download video " +
                "option inside Facebook when it is offered."
        ),
        Platform.INSTAGRAM to PlatformProvider(
            Platform.INSTAGRAM,
            "Instagram does not provide a public download endpoint. Use the platform's own " +
                "save option, or ask the creator for the original file."
        ),
        Platform.X to PlatformProvider(
            Platform.X,
            "X does not provide a public download endpoint for third-party apps. Use the " +
                "Download video option inside X when it is offered."
        ),
        Platform.TELEGRAM to PlatformProvider(
            Platform.TELEGRAM,
            "Telegram media is delivered through your own account session. Use Telegram's " +
                "own Save to downloads action."
        ),
        Platform.WHATSAPP to PlatformProvider(
            Platform.WHATSAPP,
            "WhatsApp media is end-to-end encrypted and tied to your account. Use WhatsApp's " +
                "own Save option."
        )
    )

    /** The adapter that will handle this link. */
    fun providerFor(url: String): MediaProvider {
        if (direct.canHandle(url)) return direct
        val platform = Platform.fromHost(UrlUtils.host(url))
        return platformProviders[platform] ?: direct
    }

    /** The platform this link belongs to, for display and history. */
    fun platformFor(url: String): Platform {
        val byHost = Platform.fromHost(UrlUtils.host(url))
        if (byHost != Platform.GENERIC) return byHost
        return if (UrlUtils.looksLikeDirectMedia(url)) Platform.GENERIC else Platform.BROWSER
    }

    suspend fun resolve(url: String): ResolveResult {
        if (!UrlUtils.isValid(url)) return ResolveResult.failed(ResolveFailure.INVALID_URL)
        return providerFor(url).resolve(url)
    }
}
