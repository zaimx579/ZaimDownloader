package com.zaim.downloader.download

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.zaim.downloader.data.model.DownloadStatus
import com.zaim.downloader.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Runs downloads in the background and keeps the user informed.
 *
 * It is a foreground service with the `dataSync` type, which is what Android
 * requires for a transfer that must survive the app leaving the screen. It
 * respects the user's simultaneous-download limit and stops itself when there
 * is nothing left to do, so it never lingers in the background.
 */
class DownloadForegroundService : Service() {

    companion object {
        const val ACTION_START = "com.zaim.downloader.action.START"
        const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"
        const val ACTION_CANCEL = "cancel"
        const val EXTRA_ID = "download_id"

        fun start(context: Context, id: Long) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_ID, id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = mutableMapOf<Long, Job>()
    private val lock = Mutex()
    private lateinit var repository: DownloadRepository
    private lateinit var notifications: NotificationHelper

    override fun onCreate() {
        super.onCreate()
        repository = DownloadRepository.get(this)
        notifications = NotificationHelper(this).also { it.ensureChannels() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L

        when (intent?.action) {
            ACTION_PAUSE -> if (id > 0L) scope.launch { pause(id) }
            ACTION_RESUME -> if (id > 0L) scope.launch { resume(id) }
            ACTION_CANCEL -> if (id > 0L) scope.launch { cancel(id) }
            ACTION_START -> if (id > 0L) scope.launch { startDownload(id) }
            else -> scope.launch { drainQueue() }
        }
        return START_NOT_STICKY
    }

    private suspend fun startDownload(id: Long) {
        // Promote to foreground before any work, as Android requires.
        promoteToForeground(id)
        drainQueue()
    }

    private fun promoteToForeground(id: Long) {
        val notification = notifications.buildProgress(
            title = getString(com.zaim.downloader.R.string.notif_downloading),
            percent = 0,
            speedText = "0 KB/s",
            remainingText = "--:--",
            indeterminate = true
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NotificationHelper.ID_DOWNLOAD_BASE + (id % 100).toInt(),
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NotificationHelper.ID_DOWNLOAD_BASE + (id % 100).toInt(), notification)
        }
    }

    /**
     * Starts queued downloads up to the user's parallel limit.
     *
     * The limit is read from the user's settings, so changing it in the
     * Settings screen takes effect on the next queue drain.
     */
    private suspend fun drainQueue() {
        val limit = repository.maxParallel()

        lock.withLock {
            val running = jobs.count { it.value.isActive }
            if (running >= limit) return

            val pending = repository.pendingIds()
            for (id in pending) {
                if (jobs.count { it.value.isActive } >= limit) break
                if (jobs[id]?.isActive == true) continue
                jobs[id] = scope.launch { execute(id) }
            }
        }

        if (jobs.values.none { it.isActive }) stopSelf()
    }

    private suspend fun execute(id: Long) {
        val item = repository.findById(id) ?: return
        val notificationId = NotificationHelper.ID_DOWNLOAD_BASE + (id % 100).toInt()

        repository.run(id) { progress ->
            notifications.notify(
                notificationId,
                notifications.buildProgress(
                    title = item.title,
                    percent = progress.percent,
                    speedText = progress.speedText,
                    remainingText = progress.remainingText,
                    indeterminate = progress.totalBytes <= 0L
                )
            )
        }

        // Re-read the row: the repository has just written the final status.
        // Falling back to `item` keeps this non-null, so the branches below can
        // read its fields directly.
        val finished = repository.findById(id) ?: item
        when (finished.statusEnum) {
            DownloadStatus.COMPLETED -> {
                notifications.notify(notificationId, notifications.buildComplete(finished.title))
                com.zaim.downloader.overlay.FloatingDownloadService.notifyProgress(this, 100, true)
            }
            DownloadStatus.FAILED -> {
                val reason = finished.errorCode?.let { code ->
                    runCatching {
                        getString(resources.getIdentifier(code, "string", packageName))
                    }.getOrDefault(code)
                } ?: getString(com.zaim.downloader.R.string.error_interrupted)
                notifications.notify(notificationId, notifications.buildFailed(finished.title, reason))
                com.zaim.downloader.overlay.FloatingDownloadService.notifyProgress(this, 0, false)
            }
            else -> Unit
        }

        jobs.remove(id)
        if (jobs.values.none { it.isActive }) stopSelf()
    }

    private suspend fun pause(id: Long) {
        jobs.remove(id)?.cancel()
        repository.pause(id)
    }

    private suspend fun resume(id: Long) {
        repository.resume(id)
        drainQueue()
    }

    private suspend fun cancel(id: Long) {
        jobs.remove(id)?.cancel()
        repository.cancel(id)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
