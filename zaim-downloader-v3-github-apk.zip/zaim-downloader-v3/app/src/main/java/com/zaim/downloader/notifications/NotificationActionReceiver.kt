package com.zaim.downloader.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Handles taps on notification actions (pause / resume / cancel).
 *
 * The receiver is declared in the manifest and exported=false, so only the
 * system can deliver to it.
 */
class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_PAUSE = "com.zaim.downloader.action.PAUSE"
        const val ACTION_RESUME = "com.zaim.downloader.action.RESUME"
        const val ACTION_CANCEL = "com.zaim.downloader.action.CANCEL"
        const val EXTRA_ID = "download_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ID, -1L)
        if (id <= 0L) return

        val action = when (intent.action) {
            ACTION_PAUSE -> "pause"
            ACTION_RESUME -> "resume"
            ACTION_CANCEL -> "cancel"
            else -> return
        }

        val serviceIntent = Intent(context, com.zaim.downloader.download.DownloadForegroundService::class.java).apply {
            this.action = action
            putExtra(EXTRA_ID, id)
        }
        // startForegroundService exists from API 26; on API 24-25 the plain
        // startService is the correct call and would otherwise crash.
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
