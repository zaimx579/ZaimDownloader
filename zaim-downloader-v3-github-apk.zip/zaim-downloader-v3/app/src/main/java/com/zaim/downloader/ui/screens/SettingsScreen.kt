package com.zaim.downloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaim.downloader.R
import com.zaim.downloader.data.prefs.LanguageMode
import com.zaim.downloader.data.prefs.ThemeMode
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.components.Pill
import com.zaim.downloader.ui.components.SectionHeader
import com.zaim.downloader.ui.components.ZaimCard
import com.zaim.downloader.ui.theme.ZaimGold

/**
 * Settings: download defaults, the floating circle, notifications, appearance
 * and the two legal screens.
 */
@Composable
fun SettingsScreen(
    viewModel: AppViewModel,
    onOpenAbout: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var showPrivacy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = stringResource(R.string.settings_title),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(Modifier.height(20.dp))

        // ---- Downloads -----------------------------------------------------
        SectionHeader(title = stringResource(R.string.settings_download_section))

        ZaimCard {
            Column {
                SettingRow(
                    title = stringResource(R.string.settings_default_mode),
                    value = if (settings.defaultKind == "AUDIO") {
                        stringResource(R.string.home_mode_audio)
                    } else {
                        stringResource(R.string.home_mode_video)
                    },
                    onClick = {
                        viewModel.setDefaultKind(if (settings.defaultKind == "AUDIO") "VIDEO" else "AUDIO")
                    }
                )

                Divider()

                SettingRow(
                    title = stringResource(R.string.settings_default_quality),
                    value = settings.defaultQuality,
                    onClick = {
                        val options = listOf("360p", "480p", "720p", "1080p")
                        val next = options[(options.indexOf(settings.defaultQuality) + 1) % options.size]
                        viewModel.setDefaultQuality(next)
                    }
                )

                Divider()

                SettingRow(
                    title = stringResource(R.string.settings_folder),
                    value = settings.downloadFolder,
                    onClick = { }
                )

                Divider()

                Column(Modifier.padding(vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.settings_parallel),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Pill(text = settings.maxParallel.toString())
                    }
                    Text(
                        text = stringResource(R.string.settings_parallel_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = settings.maxParallel.toFloat(),
                        onValueChange = { viewModel.setMaxParallel(it.toInt()) },
                        valueRange = 1f..5f,
                        steps = 3
                    )
                }

                Divider()

                ToggleRow(
                    title = stringResource(R.string.settings_segmented),
                    hint = stringResource(R.string.settings_segmented_hint),
                    checked = settings.segmented,
                    onCheckedChange = { viewModel.setSegmented(it) }
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- Floating circle -----------------------------------------------
        SectionHeader(title = stringResource(R.string.settings_floating_section))

        ZaimCard {
            Column {
                ToggleRow(
                    title = stringResource(R.string.settings_floating_enable),
                    hint = stringResource(R.string.settings_floating_hint),
                    checked = settings.floatingEnabled,
                    onCheckedChange = { enabled ->
                        if (enabled) {
                            if (viewModel.permissions.canDrawOverlays()) {
                                viewModel.enableFloating()
                            } else {
                                onRequestOverlay()
                            }
                        } else {
                            viewModel.disableFloating()
                        }
                    }
                )

                Divider()

                SettingRow(
                    title = stringResource(R.string.settings_floating_permission),
                    value = stringResource(
                        if (viewModel.permissions.canDrawOverlays()) {
                            R.string.settings_floating_permission_granted
                        } else {
                            R.string.settings_floating_permission_missing
                        }
                    ),
                    onClick = onRequestOverlay
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- Notifications -------------------------------------------------
        SectionHeader(title = stringResource(R.string.settings_notifications_section))

        ZaimCard {
            Column {
                ToggleRow(
                    title = stringResource(R.string.settings_notifications_enable),
                    hint = null,
                    checked = settings.notificationsEnabled,
                    onCheckedChange = { viewModel.setNotifications(it) }
                )
                Divider()
                SettingRow(
                    title = stringResource(R.string.settings_notifications_permission),
                    value = stringResource(
                        if (viewModel.permissions.hasNotificationPermission()) {
                            R.string.settings_floating_permission_granted
                        } else {
                            R.string.settings_floating_permission_missing
                        }
                    ),
                    onClick = { }
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- Appearance ----------------------------------------------------
        SectionHeader(title = stringResource(R.string.settings_appearance_section))

        ZaimCard {
            Column {
                SettingRow(
                    title = stringResource(R.string.settings_theme),
                    value = when (settings.theme) {
                        ThemeMode.DARK -> stringResource(R.string.settings_theme_dark)
                        ThemeMode.LIGHT -> stringResource(R.string.settings_theme_light)
                        ThemeMode.SYSTEM -> stringResource(R.string.settings_theme_system)
                    },
                    onClick = {
                        val next = when (settings.theme) {
                            ThemeMode.DARK -> ThemeMode.LIGHT
                            ThemeMode.LIGHT -> ThemeMode.SYSTEM
                            ThemeMode.SYSTEM -> ThemeMode.DARK
                        }
                        viewModel.setTheme(next)
                    }
                )

                Divider()

                SettingRow(
                    title = stringResource(R.string.settings_language),
                    value = when (settings.language) {
                        LanguageMode.AR -> stringResource(R.string.settings_language_ar)
                        LanguageMode.EN -> stringResource(R.string.settings_language_en)
                        LanguageMode.SYSTEM -> stringResource(R.string.settings_language_system)
                    },
                    onClick = {
                        val next = when (settings.language) {
                            LanguageMode.SYSTEM -> LanguageMode.AR
                            LanguageMode.AR -> LanguageMode.EN
                            LanguageMode.EN -> LanguageMode.SYSTEM
                        }
                        viewModel.setLanguage(next)
                    }
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ---- Legal ---------------------------------------------------------
        ZaimCard {
            Column {
                SettingRow(
                    title = stringResource(R.string.settings_privacy),
                    value = "",
                    onClick = { showPrivacy = true }
                )
                Divider()
                SettingRow(
                    title = stringResource(R.string.settings_about),
                    value = "",
                    onClick = onOpenAbout
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text(stringResource(R.string.privacy_title)) },
            text = {
                Text(
                    text = stringResource(R.string.privacy_body),
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacy = false }) {
                    Text(stringResource(R.string.common_ok), color = ZaimGold)
                }
            }
        )
    }
}

@Composable
private fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (value.isNotEmpty()) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = ZaimGold
            )
            Spacer(Modifier.width(4.dp))
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun ToggleRow(
    title: String,
    hint: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (hint != null) {
                Text(
                    text = hint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = ZaimGold
            )
        )
    }
}

@Composable
private fun Divider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    )
}
