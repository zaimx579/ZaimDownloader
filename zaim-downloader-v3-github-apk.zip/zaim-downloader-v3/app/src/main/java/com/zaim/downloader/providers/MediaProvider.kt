package com.zaim.downloader.providers

import com.zaim.downloader.data.model.MediaFormat
import com.zaim.downloader.data.model.Platform

/**
 * Why a link could not be turned into downloadable formats.
 *
 * These map 1:1 onto the error strings in `strings.xml`, so the UI can show a
 * precise, honest reason instead of a generic failure.
 */
enum class ResolveFailure(val errorCode: String) {
    INVALID_URL("error_invalid_url"),
    UNSUPPORTED_URL("error_unsupported_url"),
    NO_AUTHORIZED_METHOD("error_no_authorized_method"),
    PRIVATE_MEDIA("error_private_video"),
    PROTECTED_MEDIA("error_protected_media"),
    EXPIRED_LINK("error_expired_link"),
    UNSUPPORTED_FORMAT("error_unsupported_format"),
    NO_NETWORK("error_no_network"),
    SERVER_UNAVAILABLE("error_server_unavailable"),
    INTERRUPTED("error_interrupted")
}

/** What a provider found for a link. */
data class ResolveResult(
    val title: String,
    val formats: List<MediaFormat>,
    val thumbnailUrl: String? = null,
    val failure: ResolveFailure? = null,
    /** Extra, human-readable note shown in the picker (e.g. a platform limit). */
    val note: String? = null
) {
    val isSuccess: Boolean get() = failure == null && formats.isNotEmpty()

    companion object {
        fun failed(failure: ResolveFailure, title: String = "", note: String? = null) =
            ResolveResult(title = title, formats = emptyList(), failure = failure, note = note)
    }
}

/**
 * A source adapter.
 *
 * Contract: a provider may only return formats whose media URL is publicly
 * reachable without authentication, or that the user is authorised to fetch.
 * A provider that cannot do that MUST return a failure — never a fabricated
 * format, and never a fake success.
 */
interface MediaProvider {

    val platform: Platform

    /** True when this provider handles the given link. */
    fun canHandle(url: String): Boolean

    /** Resolves the link into the formats the source actually offers. */
    suspend fun resolve(url: String): ResolveResult
}
