package com.zaim.downloader

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaim.downloader.data.prefs.LanguageMode
import com.zaim.downloader.data.prefs.ThemeMode
import com.zaim.downloader.overlay.PendingShare
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.navigation.AppNavigation
import com.zaim.downloader.ui.screens.AnalyzeSheet
import com.zaim.downloader.ui.theme.ZaimGold
import com.zaim.downloader.ui.theme.ZaimTheme
import com.zaim.downloader.utils.UrlUtils

/**
 * The single activity.
 *
 * It hosts the Compose UI, applies the user's theme and language, and owns the
 * two permission flows: the overlay permission (with an explanation screen
 * before the system dialog) and the runtime notification permission.
 */
class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SHARED_URL = "extra_shared_url"
    }

    private val viewModel: AppViewModel by viewModels()

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        // The system does not tell us the result; re-read the real state.
        if (viewModel.permissions.canDrawOverlays()) {
            viewModel.enableFloating()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // A link shared while the app was closed arrives here.
        handleSharedIntent(intent)

        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val message by viewModel.message.collectAsStateWithLifecycle()

            var showOverlayExplanation by remember { mutableStateOf(false) }

            ZaimTheme(themeMode = settings.theme) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppNavigation(
                        viewModel = viewModel,
                        onRequestOverlay = { showOverlayExplanation = true }
                    )

                    AnalyzeSheet(viewModel = viewModel)

                    if (showOverlayExplanation) {
                        OverlayExplanationDialog(
                            onDismiss = { showOverlayExplanation = false },
                            onGrant = {
                                showOverlayExplanation = false
                                runCatching {
                                    overlayPermissionLauncher.launch(
                                        viewModel.permissions.overlaySettingsIntent()
                                    )
                                }
                            }
                        )
                    }

                    message?.let { code ->
                        val resId = resources.getIdentifier(code, "string", packageName)
                        AlertDialog(
                            onDismissRequest = { viewModel.consumeMessage() },
                            title = { Text(stringResource(R.string.app_name)) },
                            text = {
                                Text(
                                    text = if (resId != 0) stringResource(resId) else code,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            confirmButton = {
                                TextButton(onClick = { viewModel.consumeMessage() }) {
                                    Text(stringResource(R.string.common_ok), color = ZaimGold)
                                }
                            }
                        )
                    }
                }
            }
        }

        requestRuntimePermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSharedIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshFloatingState()
    }

    /**
     * A link shared into the app is analysed straight away, so the user lands on
     * the format picker instead of an empty field.
     */
    private fun handleSharedIntent(intent: Intent?) {
        val shared = intent?.getStringExtra(EXTRA_SHARED_URL)
            ?: intent?.getStringExtra(Intent.EXTRA_TEXT)?.let(UrlUtils::firstUrl)
            ?: PendingShare.url(this)

        if (!shared.isNullOrBlank() && UrlUtils.isValid(shared)) {
            viewModel.analyzeLink(shared)
        }
    }

    private fun requestRuntimePermissions() {
        val needed = viewModel.permissions.runtimePermissions()
            .filterNot { permission ->
                checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
            }
        if (needed.isNotEmpty()) {
            notificationPermissionLauncher.launch(needed.toTypedArray())
        }
    }
}

/**
 * The explanation shown before the overlay permission dialog.
 *
 * Android requires the app to say why it needs to draw over other apps, and the
 * user deserves a plain answer: it is for the floating circle, nothing else.
 */
@Composable
private fun OverlayExplanationDialog(onDismiss: () -> Unit, onGrant: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.overlay_permission_title)) },
        text = {
            Text(
                text = stringResource(R.string.overlay_permission_body),
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = onGrant,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ZaimGold,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(stringResource(R.string.overlay_permission_grant))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.overlay_permission_later))
            }
        }
    )
}
