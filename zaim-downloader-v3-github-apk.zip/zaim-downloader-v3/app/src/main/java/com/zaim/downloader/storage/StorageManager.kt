package com.zaim.downloader.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.zaim.downloader.data.model.MediaKind
import java.io.File

/**
 * Where finished files go.
 *
 * Android 10+ (API 29) uses scoped storage: the file is written into the app's
 * own cache while downloading, then published into the public Downloads
 * collection through MediaStore. Android 9 and below writes straight into the
 * public Downloads directory, which is why the manifest declares
 * WRITE_EXTERNAL_STORAGE with `maxSdkVersion="28"`.
 */
class StorageManager(private val context: Context) {

    /** Working file the engine streams into. Always app-private. */
    fun workingFile(fileName: String): File {
        val dir = File(context.cacheDir, "downloads").apply { mkdirs() }
        return File(dir, fileName)
    }

    /** True when there is room for [bytes] plus a safety margin. */
    fun hasSpaceFor(bytes: Long): Boolean {
        if (bytes <= 0L) return true
        val stat = android.os.StatFs(Environment.getDataDirectory().path)
        val available = stat.availableBlocksLong * stat.blockSizeLong
        return available > bytes + (50L * 1024L * 1024L)
    }

    /**
     * Publishes a finished file into the user's Downloads collection.
     *
     * @return the MediaStore URI on API 29+, or the absolute path on older
     *         versions. Null when the publish step failed — the caller then
     *         keeps the app-private copy rather than claiming success.
     */
    fun publish(file: File, fileName: String, kind: MediaKind, folder: String): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            publishViaMediaStore(file, fileName, kind, folder)
        } else {
            publishLegacy(file, fileName, folder)
        }
    }

    private fun publishViaMediaStore(file: File, fileName: String, kind: MediaKind, folder: String): String? {
        val collection = if (kind == MediaKind.AUDIO) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeTypeFor(fileName, kind))
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val uri: Uri = try {
            context.contentResolver.insert(collection, values) ?: return null
        } catch (e: Exception) {
            return null
        }

        try {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                file.inputStream().use { input -> input.copyTo(output) }
            } ?: return null
        } catch (e: Exception) {
            runCatching { context.contentResolver.delete(uri, null, null) }
            return null
        }

        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        runCatching { context.contentResolver.update(uri, values, null, null) }

        file.delete()
        return uri.toString()
    }

    @Suppress("DEPRECATION")
    private fun publishLegacy(file: File, fileName: String, folder: String): String? {
        return try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folder)
            if (!dir.exists() && !dir.mkdirs()) return null
            val target = File(dir, fileName)
            file.inputStream().use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            file.delete()
            target.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun mimeTypeFor(fileName: String, kind: MediaKind): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            "avi" -> "video/x-msvideo"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg", "opus" -> "audio/ogg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            else -> if (kind == MediaKind.AUDIO) "audio/*" else "video/*"
        }
    }
}
