package com.zaim.downloader.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zaim.downloader.R
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.screens.AboutScreen
import com.zaim.downloader.ui.screens.DownloadsScreen
import com.zaim.downloader.ui.screens.HomeScreen
import com.zaim.downloader.ui.screens.SettingsScreen
import com.zaim.downloader.ui.theme.ZaimGold

/** The app's destinations. */
object Routes {
    const val HOME = "home"
    const val DOWNLOADS = "downloads"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
}

private data class TabItem(val route: String, val labelRes: Int, val icon: ImageVector)

/**
 * The app shell: a three-tab bottom bar plus the About screen, which is pushed
 * on top of Settings rather than being a tab of its own.
 */
@Composable
fun AppNavigation(
    viewModel: AppViewModel,
    onRequestOverlay: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val tabs = listOf(
        TabItem(Routes.HOME, R.string.nav_home, Icons.Rounded.Home),
        TabItem(Routes.DOWNLOADS, R.string.nav_downloads, Icons.Rounded.Download),
        TabItem(Routes.SETTINGS, R.string.nav_settings, Icons.Rounded.Settings)
    )

    val showBar = currentRoute in tabs.map { it.route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    tabs.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = stringResource(tab.labelRes)
                                )
                            },
                            label = { Text(stringResource(tab.labelRes)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ZaimGold,
                                selectedTextColor = ZaimGold,
                                indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    viewModel = viewModel,
                    onOpenDownloads = { navController.navigate(Routes.DOWNLOADS) },
                    onRequestOverlay = onRequestOverlay
                )
            }
            composable(Routes.DOWNLOADS) {
                DownloadsScreen(viewModel = viewModel)
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onOpenAbout = { navController.navigate(Routes.ABOUT) },
                    onRequestOverlay = onRequestOverlay
                )
            }
            composable(Routes.ABOUT) {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
