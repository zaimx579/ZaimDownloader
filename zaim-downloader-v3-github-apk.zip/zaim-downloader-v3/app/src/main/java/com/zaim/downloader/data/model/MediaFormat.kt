package com.zaim.downloader.data.model

/** Whether a resolved format carries video or audio. */
enum class MediaKind {
    VIDEO,
    AUDIO;

    companion object {
        fun fromName(value: String?): MediaKind =
            values().firstOrNull { it.name == value } ?: VIDEO
    }
}

/**
 * One downloadable rendition offered by a source.
 *
 * [url] is the direct media URL the engine will fetch. [requiresMux] marks a
 * video-only stream that would need a separate audio track merged in; the app
 * never claims to mux, so such formats are surfaced as video-only.
 */
data class MediaFormat(
    val id: String,
    val kind: MediaKind,
    val label: String,
    val container: String,
    val url: String,
    val height: Int? = null,
    val bitrateKbps: Int? = null,
    val sizeBytes: Long? = null,
    val requiresMux: Boolean = false
) {
    val isVideo: Boolean get() = kind == MediaKind.VIDEO

    /** e.g. "720p · MP4" or "128 kbps · M4A". */
    val summary: String
        get() = buildString {
            append(label)
            if (container.isNotBlank()) {
                append(" · ")
                append(container.uppercase())
            }
        }
}
