package com.zaim.downloader.ui.theme

import androidx.compose.ui.graphics.Color

// ZAIM brand palette: deep black, dark charcoal, premium gold, white.
val ZaimBlack = Color(0xFF0A0A0B)
val ZaimCharcoal = Color(0xFF16171A)
val ZaimCharcoalLight = Color(0xFF1F2126)
val ZaimCharcoalLighter = Color(0xFF2A2D33)

val ZaimGold = Color(0xFFD4AF37)
val ZaimGoldLight = Color(0xFFE8C766)
val ZaimGoldDark = Color(0xFFA8862A)

val ZaimWhite = Color(0xFFFFFFFF)
val ZaimOffWhite = Color(0xFFF5F5F7)
val ZaimGrey = Color(0xFF8A8D94)
val ZaimGreyLight = Color(0xFFB9BCC4)

val ZaimError = Color(0xFFE5484D)
val ZaimSuccess = Color(0xFF3DD68C)
val ZaimWarning = Color(0xFFF5A524)

// Light theme surfaces
val LightBackground = Color(0xFFFAFAFB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F0F3)
val LightOnSurface = Color(0xFF14151A)
val LightOutline = Color(0xFFDCDDE2)
