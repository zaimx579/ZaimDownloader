package com.zaim.downloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zaim.downloader.data.model.DownloadItem
import com.zaim.downloader.data.model.MediaFormat
import com.zaim.downloader.data.prefs.AppSettings
import com.zaim.downloader.data.prefs.LanguageMode
import com.zaim.downloader.data.prefs.SettingsStore
import com.zaim.downloader.data.prefs.ThemeMode
import com.zaim.downloader.download.DownloadForegroundService
import com.zaim.downloader.download.DownloadRepository
import com.zaim.downloader.overlay.FloatingDownloadService
import com.zaim.downloader.overlay.PendingShare
import com.zaim.downloader.permissions.PermissionManager
import com.zaim.downloader.providers.ResolveResult
import com.zaim.downloader.utils.UrlUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** What the format picker is currently showing. */
sealed interface AnalyzeState {
    data object Idle : AnalyzeState
    data object Loading : AnalyzeState
    data class Success(val url: String, val result: ResolveResult) : AnalyzeState
    data class Failure(val url: String, val result: ResolveResult) : AnalyzeState
}

/**
 * One view model for the whole app.
 *
 * The app is small enough that a single source of truth is clearer than a
 * view model per screen, and it keeps the floating circle, the services and the
 * UI reading exactly the same state.
 */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = DownloadRepository.get(app)
    private val settingsStore = SettingsStore(app)
    val permissions = PermissionManager(app)

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val allDownloads: StateFlow<List<DownloadItem>> = repository.observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeDownloads: StateFlow<List<DownloadItem>> = repository.observeActive()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val completedDownloads: StateFlow<List<DownloadItem>> = repository.observeCompleted()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val failedDownloads: StateFlow<List<DownloadItem>> = repository.observeFailed()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentDownloads: StateFlow<List<DownloadItem>> = repository.observeRecent(4)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _analyze = MutableStateFlow<AnalyzeState>(AnalyzeState.Idle)
    val analyze: StateFlow<AnalyzeState> = _analyze.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _floatingActive = MutableStateFlow(FloatingDownloadService.isRunning())
    val floatingActive: StateFlow<Boolean> = _floatingActive.asStateFlow()

    // ---- Analyze -----------------------------------------------------------

    fun analyzeLink(rawInput: String) {
        val url = UrlUtils.firstUrl(rawInput) ?: rawInput.trim()
        if (!UrlUtils.isValid(url)) {
            _message.value = "error_invalid_url"
            return
        }

        _analyze.value = AnalyzeState.Loading
        viewModelScope.launch {
            val result = repository.resolve(url)
            _analyze.value = if (result.isSuccess) {
                AnalyzeState.Success(url, result)
            } else {
                AnalyzeState.Failure(url, result)
            }
        }
    }

    fun dismissAnalyze() {
        _analyze.value = AnalyzeState.Idle
    }

    /** Queues the chosen format and starts the transfer. */
    fun startDownload(url: String, title: String, format: MediaFormat, thumbnailUrl: String?) {
        viewModelScope.launch {
            val id = repository.enqueue(url, title, format, thumbnailUrl)
            if (id == null) {
                _message.value = "error_duplicate"
                return@launch
            }
            PendingShare.clear(getApplication())
            DownloadForegroundService.start(getApplication(), id)
            _analyze.value = AnalyzeState.Idle
        }
    }

    /** Quick download using the user's saved defaults. */
    fun quickDownload(rawInput: String) {
        val url = UrlUtils.firstUrl(rawInput) ?: rawInput.trim()
        if (!UrlUtils.isValid(url)) {
            _message.value = "error_invalid_url"
            return
        }

        viewModelScope.launch {
            val result = repository.resolve(url)
            if (!result.isSuccess) {
                _analyze.value = AnalyzeState.Failure(url, result)
                return@launch
            }

            val prefs = settings.value
            val wantedKind = prefs.defaultKind
            val wantedQuality = prefs.defaultQuality

            val format = result.formats.firstOrNull { it.kind.name == wantedKind && it.label.contains(wantedQuality) }
                ?: result.formats.firstOrNull { it.kind.name == wantedKind }
                ?: result.formats.first()

            startDownload(url, result.title, format, result.thumbnailUrl)
        }
    }

    // ---- Management --------------------------------------------------------

    fun pause(id: Long) = viewModelScope.launch { repository.pause(id) }
    fun resume(id: Long) = viewModelScope.launch { repository.resume(id) }
    fun cancel(id: Long) = viewModelScope.launch { repository.cancel(id) }
    fun retry(id: Long) = viewModelScope.launch { repository.retry(id) }
    fun delete(id: Long, deleteFile: Boolean) = viewModelScope.launch { repository.delete(id, deleteFile) }
    fun clearFinished() = viewModelScope.launch { repository.clearFinished() }

    // ---- Floating circle ---------------------------------------------------

    fun enableFloating() {
        viewModelScope.launch {
            settingsStore.setFloatingEnabled(true)
            FloatingDownloadService.show(getApplication())
            _floatingActive.value = true
        }
    }

    fun disableFloating() {
        viewModelScope.launch {
            settingsStore.setFloatingEnabled(false)
            FloatingDownloadService.hide(getApplication())
            _floatingActive.value = false
        }
    }

    fun refreshFloatingState() {
        _floatingActive.value = FloatingDownloadService.isRunning()
    }

    // ---- Settings ----------------------------------------------------------

    fun setDefaultKind(value: String) = viewModelScope.launch { settingsStore.setDefaultKind(value) }
    fun setDefaultQuality(value: String) = viewModelScope.launch { settingsStore.setDefaultQuality(value) }
    fun setMaxParallel(value: Int) = viewModelScope.launch { settingsStore.setMaxParallel(value) }
    fun setSegmented(value: Boolean) = viewModelScope.launch { settingsStore.setSegmented(value) }
    fun setNotifications(value: Boolean) = viewModelScope.launch { settingsStore.setNotificationsEnabled(value) }
    fun setTheme(value: ThemeMode) = viewModelScope.launch { settingsStore.setTheme(value) }
    fun setLanguage(value: LanguageMode) = viewModelScope.launch { settingsStore.setLanguage(value) }

    fun consumeMessage() {
        _message.value = null
    }
}
