package com.zaim.downloader.overlay

import android.content.Context

/**
 * The link the user most recently shared with the app.
 *
 * It is held in SharedPreferences rather than in memory so it survives the
 * process being killed between the share and the tap on the floating circle —
 * which is exactly the window the overlay exists for.
 */
object PendingShare {

    private const val PREFS = "zaim_pending_share"
    private const val KEY_URL = "pending_url"
    private const val KEY_TITLE = "pending_title"

    fun put(context: Context, url: String, title: String? = null) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_URL, url)
            .putString(KEY_TITLE, title)
            .apply()
    }

    fun url(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_URL, null)

    fun title(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TITLE, null)

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
