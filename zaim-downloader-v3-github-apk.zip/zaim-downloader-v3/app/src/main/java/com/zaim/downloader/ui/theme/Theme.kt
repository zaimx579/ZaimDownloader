package com.zaim.downloader.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.zaim.downloader.data.prefs.ThemeMode

private val DarkColors = darkColorScheme(
    primary = ZaimGold,
    onPrimary = ZaimBlack,
    primaryContainer = ZaimGoldDark,
    onPrimaryContainer = ZaimBlack,
    secondary = ZaimGoldLight,
    onSecondary = ZaimBlack,
    background = ZaimBlack,
    onBackground = ZaimWhite,
    surface = ZaimCharcoal,
    onSurface = ZaimWhite,
    surfaceVariant = ZaimCharcoalLight,
    onSurfaceVariant = ZaimGreyLight,
    outline = ZaimCharcoalLighter,
    outlineVariant = ZaimCharcoalLight,
    error = ZaimError,
    onError = ZaimWhite
)

private val LightColors = lightColorScheme(
    primary = ZaimGoldDark,
    onPrimary = ZaimWhite,
    primaryContainer = ZaimGoldLight,
    onPrimaryContainer = ZaimBlack,
    secondary = ZaimGoldDark,
    onSecondary = ZaimWhite,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF5A5D66),
    outline = LightOutline,
    outlineVariant = LightSurfaceVariant,
    error = ZaimError,
    onError = ZaimWhite
)

/**
 * Applies the ZAIM theme.
 *
 * The status and navigation bars are tinted to match, so the black-and-gold
 * look runs edge to edge instead of stopping at a grey system bar.
 */
@Composable
fun ZaimTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colors = if (dark) DarkColors else LightColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colors.background.toArgb()
            window.navigationBarColor = colors.background.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(
        colorScheme = colors,
        typography = ZaimTypography,
        content = content
    )
}
