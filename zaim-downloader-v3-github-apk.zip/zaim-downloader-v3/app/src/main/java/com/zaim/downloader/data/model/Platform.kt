package com.zaim.downloader.data.model

/**
 * A source the app recognises. Detection is purely host-based and offline.
 *
 * Recognising a platform does NOT mean the app can download from it: each
 * provider decides separately whether an authorised download method exists.
 */
enum class Platform(
    val id: String,
    val displayName: String,
    val hostPatterns: List<String>
) {
    YOUTUBE("youtube", "YouTube", listOf("youtube.com", "youtu.be", "youtube-nocookie.com")),
    TIKTOK("tiktok", "TikTok", listOf("tiktok.com", "vm.tiktok.com", "vt.tiktok.com")),
    FACEBOOK("facebook", "Facebook", listOf("facebook.com", "fb.watch", "fb.com")),
    INSTAGRAM("instagram", "Instagram", listOf("instagram.com", "instagr.am")),
    X("x", "X", listOf("x.com", "twitter.com", "t.co")),
    TELEGRAM("telegram", "Telegram", listOf("t.me", "telegram.me", "telegram.org")),
    WHATSAPP("whatsapp", "WhatsApp", listOf("whatsapp.com", "wa.me")),
    BROWSER("browser", "Browser", emptyList()),
    GENERIC("generic", "Direct link", emptyList());

    companion object {
        /** Platforms shown as chips on the home screen. */
        val advertised: List<Platform>
            get() = listOf(YOUTUBE, TIKTOK, FACEBOOK, INSTAGRAM, X, TELEGRAM, WHATSAPP, BROWSER)

        fun fromId(id: String?): Platform =
            values().firstOrNull { it.id == id } ?: GENERIC

        fun fromHost(host: String?): Platform {
            val h = host?.lowercase().orEmpty()
            if (h.isEmpty()) return GENERIC
            return values().firstOrNull { platform ->
                platform.hostPatterns.any { pattern -> h == pattern || h.endsWith("." + pattern) }
            } ?: GENERIC
        }
    }
}
