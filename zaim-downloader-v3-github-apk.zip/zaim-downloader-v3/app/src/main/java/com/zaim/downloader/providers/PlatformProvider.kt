package com.zaim.downloader.providers

import com.zaim.downloader.data.model.Platform

/**
 * Adapter for a named social platform.
 *
 * Every one of these platforms serves its media through an authenticated,
 * signed or DRM-protected pipeline. There is no public, authorised endpoint
 * that hands out the file, and the app must not pretend otherwise — so these
 * adapters deliberately return [ResolveFailure.NO_AUTHORIZED_METHOD] and point
 * the user at the platform's own download feature.
 *
 * The class exists as a real, wired-up adapter (not a stub): it is registered
 * in [ProviderRegistry], it is selected by host, and it produces the exact
 * message the UI shows. If a platform ever publishes an authorised download
 * API, only this class needs to change.
 */
class PlatformProvider(
    override val platform: Platform,
    private val authorizedNote: String
) : MediaProvider {

    override fun canHandle(url: String): Boolean {
        val host = com.zaim.downloader.utils.UrlUtils.host(url)
        return platform.hostPatterns.any { host == it || host.endsWith(".$it") }
    }

    override suspend fun resolve(url: String): ResolveResult =
        ResolveResult.failed(
            failure = ResolveFailure.NO_AUTHORIZED_METHOD,
            title = platform.displayName,
            note = authorizedNote
        )
}
