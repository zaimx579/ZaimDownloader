package com.zaim.downloader.overlay

import android.animation.ObjectAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.zaim.downloader.R
import com.zaim.downloader.download.DownloadForegroundService
import com.zaim.downloader.download.DownloadRepository
import com.zaim.downloader.notifications.NotificationHelper
import com.zaim.downloader.utils.UrlUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The floating download circle.
 *
 * This is the app's headline feature: a draggable gold circle that sits above
 * other applications, shows live progress, and starts the download of the link
 * the user just shared — one tap, no copy and paste.
 *
 * It only ever runs when the user has explicitly granted the overlay permission
 * and switched the circle on in Settings. It draws one small button and reads
 * nothing from the apps underneath it.
 */
class FloatingDownloadService : Service() {

    companion object {
        const val ACTION_SHOW = "com.zaim.downloader.overlay.SHOW"
        const val ACTION_HIDE = "com.zaim.downloader.overlay.HIDE"

        @Volatile
        private var instance: FloatingDownloadService? = null

        fun show(context: Context) {
            val intent = Intent(context, FloatingDownloadService::class.java).apply { action = ACTION_SHOW }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun hide(context: Context) {
            val intent = Intent(context, FloatingDownloadService::class.java).apply { action = ACTION_HIDE }
            runCatching { context.startService(intent) }
        }

        fun isRunning(): Boolean = instance != null

        /** Called by the download service so the ring tracks the transfer. */
        fun notifyProgress(context: Context, percent: Int, finished: Boolean) {
            instance?.applyProgress(percent, finished)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var rootView: View
    private lateinit var ring: ProgressRingView
    private lateinit var percentLabel: TextView
    private lateinit var controls: LinearLayout
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var minimized = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        NotificationHelper(this).ensureChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                promoteToForeground()
                if (!Settings.canDrawOverlays(this)) {
                    // Permission was revoked while the service was off.
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (rootView.parent == null) attachView()
            }
        }
        return START_STICKY
    }

    private fun promoteToForeground() {
        val notification = NotificationHelper(this).buildFloating()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NotificationHelper.ID_FLOATING,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NotificationHelper.ID_FLOATING, notification)
        }
    }

    // ---- View construction -------------------------------------------------

    private fun attachView() {
        val size = dp(64)

        val container = FrameLayout(this)

        // The gold circle itself.
        val button = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#16171A"))
                setStroke(dp(2), Color.parseColor("#D4AF37"))
            }
            elevation = dp(8).toFloat()
        }

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_overlay_download)
            layoutParams = FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER)
        }
        button.addView(icon)

        ring = ProgressRingView(this).apply {
            layoutParams = FrameLayout.LayoutParams(size, size)
        }

        percentLabel = TextView(this).apply {
            setTextColor(Color.parseColor("#D4AF37"))
            textSize = 11f
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(size, size)
            visibility = View.GONE
        }

        container.addView(button, FrameLayout.LayoutParams(size, size))
        container.addView(ring)
        container.addView(percentLabel)

        // Minimize / close controls, revealed by a long press.
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
        }
        controls.addView(smallButton(R.string.overlay_minimize) { toggleMinimize() })
        controls.addView(smallButton(R.string.overlay_close) { stopSelf() })
        container.addView(controls)

        rootView = container

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(220)
        }

        attachTouchHandlers(button)
        windowManager.addView(rootView, layoutParams)

        // A gentle pulse so the circle reads as alive without being distracting.
        ObjectAnimator.ofFloat(button, View.ALPHA, 1f, 0.82f, 1f).apply {
            duration = 2200L
            repeatCount = ObjectAnimator.INFINITE
            start()
        }
    }

    private fun smallButton(labelRes: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = getString(labelRes)
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#CC16171A"))
                setStroke(dp(1), Color.parseColor("#D4AF37"))
            }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
        }

    // ---- Interaction -------------------------------------------------------

    private fun attachTouchHandlers(button: View) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var dragged = false

        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragged = false
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90L).start()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                    layoutParams.x = (initialX + dx).roundToInt()
                    layoutParams.y = (initialY + dy).roundToInt()
                    runCatching { windowManager.updateViewLayout(rootView, layoutParams) }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                    if (!dragged) {
                        onCircleTapped()
                    } else {
                        snapToEdge()
                    }
                    true
                }

                else -> false
            }
        }

        button.setOnLongClickListener {
            controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            true
        }
    }

    /** Keeps the circle reachable: it settles against the nearest side. */
    private fun snapToEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val target = if (layoutParams.x + dp(32) < screenWidth / 2) dp(16) else screenWidth - dp(80)
        android.animation.ValueAnimator.ofInt(layoutParams.x, target).apply {
            duration = 220L
            addUpdateListener { animator ->
                layoutParams.x = animator.animatedValue as Int
                runCatching { windowManager.updateViewLayout(rootView, layoutParams) }
            }
            start()
        }
    }

    private fun toggleMinimize() {
        minimized = !minimized
        val scale = if (minimized) 0.6f else 1f
        rootView.animate().scaleX(scale).scaleY(scale).setDuration(180L).start()
        controls.visibility = View.GONE
    }

    /**
     * One tap: take the link the user shared and start downloading it.
     *
     * The link is resolved first, so the app never starts a transfer it cannot
     * finish — and never shows a success it did not achieve.
     */
    private fun onCircleTapped() {
        val url = PendingShare.url(this)
        if (url.isNullOrBlank() || !UrlUtils.isValid(url)) {
            // Nothing shared yet: open the app so the user can paste a link.
            openApp()
            return
        }

        scope.launch {
            val repository = DownloadRepository.get(applicationContext)
            val result = repository.resolve(url)

            if (!result.isSuccess) {
                // Honest failure: surface the reason in the app, do not fake it.
                openApp()
                return@launch
            }

            val format = result.formats.firstOrNull() ?: run {
                openApp()
                return@launch
            }

            val id = repository.enqueue(url, result.title, format, result.thumbnailUrl)
            if (id == null) {
                openApp()
                return@launch
            }

            PendingShare.clear(applicationContext)
            DownloadForegroundService.start(applicationContext, id)
            applyProgress(0, false)
        }
    }

    private fun openApp() {
        val intent = Intent(this, com.zaim.downloader.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        startActivity(intent)
    }

    /** Updates the ring and the percentage label. */
    private fun applyProgress(percent: Int, finished: Boolean) {
        scope.launch {
            if (!::ring.isInitialized) return@launch
            ring.progress = percent / 100f
            if (percent in 1..99) {
                percentLabel.text = "$percent%"
                percentLabel.visibility = View.VISIBLE
            } else {
                percentLabel.visibility = View.GONE
            }
            if (finished) {
                ring.progress = 0f
                percentLabel.visibility = View.GONE
            }
        }
    }

    override fun onDestroy() {
        instance = null
        if (::rootView.isInitialized && rootView.parent != null) {
            runCatching { windowManager.removeView(rootView) }
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
