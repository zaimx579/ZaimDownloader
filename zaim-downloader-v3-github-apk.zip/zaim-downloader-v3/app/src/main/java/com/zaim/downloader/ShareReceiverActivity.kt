package com.zaim.downloader

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.zaim.downloader.overlay.FloatingDownloadService
import com.zaim.downloader.overlay.PendingShare
import com.zaim.downloader.permissions.PermissionManager
import com.zaim.downloader.utils.UrlUtils

/**
 * Entry point for a link shared from another app.
 *
 * Flow: the user taps Share in YouTube / TikTok / a browser → ZAIM Downloader
 * appears in the Sharesheet → this activity receives the link, stores it, makes
 * sure the floating circle is available, and gets out of the way.
 *
 * It is deliberately invisible (transparent, no history) so the share feels
 * instant and the user lands back where they were.
 */
class ShareReceiverActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val url = extractUrl(intent)
        if (url == null) {
            Toast.makeText(this, R.string.error_invalid_url, Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        PendingShare.put(this, url, intent.getStringExtra(Intent.EXTRA_SUBJECT))

        val permissions = PermissionManager(this)
        if (permissions.canDrawOverlays()) {
            // The circle is the whole point: bring it up so the next tap starts
            // the download, exactly as the brief describes.
            FloatingDownloadService.show(this)
            Toast.makeText(this, R.string.overlay_start, Toast.LENGTH_SHORT).show()
        } else {
            // No overlay permission yet: open the app, which explains why the
            // permission is needed before asking for it.
            startActivity(
                Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(MainActivity.EXTRA_SHARED_URL, url)
                }
            )
        }

        finish()
    }

    /** Pulls a link out of ACTION_SEND text, a media stream, or ACTION_VIEW. */
    private fun extractUrl(intent: Intent?): String? {
        if (intent == null) return null

        val candidates = buildList {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { add(it) }
            intent.getStringExtra(Intent.EXTRA_SUBJECT)?.let { add(it) }
            intent.dataString?.let { add(it) }
            intent.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).text?.toString()?.let { add(it) }
                    clip.getItemAt(i).uri?.toString()?.let { add(it) }
                }
            }
        }

        for (candidate in candidates) {
            val url = UrlUtils.firstUrl(candidate) ?: candidate.takeIf { UrlUtils.isValid(it) }
            if (url != null && UrlUtils.isValid(url)) return url
        }
        return null
    }
}
