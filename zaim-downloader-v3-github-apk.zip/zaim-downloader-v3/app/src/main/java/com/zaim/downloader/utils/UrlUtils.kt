package com.zaim.downloader.utils

import java.net.URI
import java.util.Locale

/** Link parsing and validation. Pure functions, no Android dependencies. */
object UrlUtils {

    private val URL_REGEX = Regex("""https?://[^\s"'<>()\[\]{}]+""", RegexOption.IGNORE_CASE)

    private val TRAILING_JUNK = charArrayOf('.', ',', ')', ']', '}', '"', '\'', '>', ';', ':')

    /** Pulls the first http(s) link out of arbitrary shared text. */
    fun firstUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val match = URL_REGEX.find(text) ?: return null
        return match.value.trimEnd(*TRAILING_JUNK)
    }

    fun isValid(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        return try {
            val uri = URI(url)
            val scheme = uri.scheme?.lowercase(Locale.ROOT)
            (scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()
        } catch (e: Exception) {
            false
        }
    }

    fun host(url: String?): String =
        try {
            URI(url.orEmpty()).host?.lowercase(Locale.ROOT).orEmpty()
        } catch (e: Exception) {
            ""
        }

    /**
     * Best-effort file name. Prefers the last path segment; falls back to a
     * timestamped name so two downloads never collide.
     */
    fun fileNameFrom(url: String?, fallbackExtension: String): String {
        val raw = try {
            URI(url.orEmpty()).path.orEmpty().substringAfterLast('/')
        } catch (e: Exception) {
            ""
        }
        val cleaned = raw.substringBefore('?').trim()
        val safe = cleaned.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (safe.isNotEmpty() && safe.contains('.')) return safe
        val ext = fallbackExtension.removePrefix(".").ifBlank { "bin" }
        val base = if (safe.isNotEmpty()) safe else "zaim_${System.currentTimeMillis()}"
        return "$base.$ext"
    }

    /** True when the path itself looks like a media file. */
    fun looksLikeDirectMedia(url: String?): Boolean {
        val path = try {
            URI(url.orEmpty()).path.orEmpty().lowercase(Locale.ROOT)
        } catch (e: Exception) {
            return false
        }
        return MEDIA_EXTENSIONS.any { path.endsWith(it) }
    }

    val MEDIA_EXTENSIONS = listOf(
        ".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi", ".3gp",
        ".mp3", ".m4a", ".aac", ".ogg", ".opus", ".wav", ".flac"
    )
}
