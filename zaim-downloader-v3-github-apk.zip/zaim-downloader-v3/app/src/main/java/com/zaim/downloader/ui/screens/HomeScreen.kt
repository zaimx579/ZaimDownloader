package com.zaim.downloader.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaim.downloader.R
import com.zaim.downloader.data.model.DownloadItem
import com.zaim.downloader.data.model.Platform
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.components.GoldGradient
import com.zaim.downloader.ui.components.Pill
import com.zaim.downloader.ui.components.SectionHeader
import com.zaim.downloader.ui.components.ZaimCard
import com.zaim.downloader.ui.components.ZaimLogo
import com.zaim.downloader.ui.theme.ZaimGold
import com.zaim.downloader.ui.theme.ZaimGoldDark
import com.zaim.downloader.ui.theme.ZaimGoldLight

/**
 * The home screen.
 *
 * The floating circle is the hero: a large gold button that mirrors the overlay
 * and explains the share → circle → one tap flow. The URL field is the
 * secondary path, exactly as the brief asks.
 */
@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onOpenDownloads: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    val recent by viewModel.recentDownloads.collectAsStateWithLifecycle()
    val floatingActive by viewModel.floatingActive.collectAsStateWithLifecycle()

    var urlInput by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))

        // ---- Brand ---------------------------------------------------------
        Row(verticalAlignment = Alignment.CenterVertically) {
            ZaimLogo(size = 52)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    text = stringResource(R.string.home_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        // ---- The hero circle ----------------------------------------------
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            FloatingHeroButton(
                active = floatingActive,
                onClick = {
                    if (floatingActive) {
                        viewModel.disableFloating()
                    } else if (viewModel.permissions.canDrawOverlays()) {
                        viewModel.enableFloating()
                    } else {
                        onRequestOverlay()
                    }
                }
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = stringResource(
                if (floatingActive) R.string.home_floating_on else R.string.home_floating_off
            ),
            style = MaterialTheme.typography.labelLarge,
            color = if (floatingActive) ZaimGold else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(6.dp))

        Text(
            text = stringResource(
                if (floatingActive) R.string.home_disable_floating else R.string.home_enable_floating
            ),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(28.dp))

        // ---- URL input (secondary path) -----------------------------------
        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.home_url_hint)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Rounded.Link,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingIcon = {
                IconButton(
                    onClick = { viewModel.analyzeLink(urlInput) },
                    enabled = urlInput.isNotBlank()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = stringResource(R.string.home_analyze),
                        tint = if (urlInput.isNotBlank()) ZaimGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { viewModel.analyzeLink(urlInput) }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ZaimGold,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { viewModel.analyzeLink(urlInput) },
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                )
            ) {
                Text(stringResource(R.string.home_analyze))
            }

            Button(
                onClick = { viewModel.quickDownload(urlInput) },
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ZaimGold,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.home_quick_download), fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.height(28.dp))

        // ---- Supported sources --------------------------------------------
        SectionHeader(title = stringResource(R.string.home_supported))
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Platform.advertised) { platform ->
                Pill(
                    text = platform.displayName,
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // ---- Recent --------------------------------------------------------
        SectionHeader(
            title = stringResource(R.string.home_recent),
            trailing = {
                if (recent.isNotEmpty()) {
                    TextButton(onClick = onOpenDownloads) {
                        Text(stringResource(R.string.nav_downloads), color = ZaimGold)
                    }
                }
            }
        )

        if (recent.isEmpty()) {
            ZaimCard {
                Text(
                    text = stringResource(R.string.home_no_recent),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                recent.forEach { item ->
                    RecentRow(item = item, onClick = onOpenDownloads)
                }
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

/** The big gold circle on the home screen. */
@Composable
private fun FloatingHeroButton(active: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (active) 1.06f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(contentAlignment = Alignment.Center) {
        // Soft outer glow
        Box(
            modifier = Modifier
                .size(168.dp)
                .scale(pulse)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            ZaimGold.copy(alpha = if (active) 0.22f else 0.10f),
                            ZaimGold.copy(alpha = 0f)
                        )
                    )
                )
        )

        Box(
            modifier = Modifier
                .size(132.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .border(2.dp, if (active) ZaimGold else ZaimGoldDark, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(GoldGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Download,
                    contentDescription = stringResource(R.string.overlay_start),
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(44.dp)
                )
            }
        }
    }
}

/** One compact row in the recent list. */
@Composable
private fun RecentRow(item: DownloadItem, onClick: () -> Unit) {
    ZaimCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Download,
                    contentDescription = null,
                    tint = ZaimGold,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Text(
                    text = "${item.platform.displayName} · ${item.formatLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "${item.progressPercent}%",
                style = MaterialTheme.typography.labelMedium,
                color = if (item.statusEnum.name == "COMPLETED") ZaimGold else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
