package com.zaim.downloader.download

import android.content.Context
import com.zaim.downloader.data.db.AppDatabase
import com.zaim.downloader.data.db.DownloadDao
import com.zaim.downloader.data.model.DownloadItem
import com.zaim.downloader.data.model.DownloadStatus
import com.zaim.downloader.data.model.MediaFormat
import com.zaim.downloader.data.model.MediaKind
import com.zaim.downloader.data.model.Platform
import com.zaim.downloader.data.prefs.SettingsStore
import com.zaim.downloader.providers.ProviderRegistry
import com.zaim.downloader.providers.ResolveResult
import com.zaim.downloader.storage.StorageManager
import com.zaim.downloader.utils.UrlUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import java.io.File

/**
 * The single place the UI and the services talk to.
 *
 * It owns the database, the provider registry, the engine and storage, so no
 * screen ever touches OkHttp or Room directly.
 */
class DownloadRepository private constructor(
    private val context: Context,
    private val dao: DownloadDao,
    private val registry: ProviderRegistry,
    private val engine: DownloadEngine,
    private val storage: StorageManager,
    private val settings: SettingsStore
) {

    companion object {
        @Volatile
        private var instance: DownloadRepository? = null

        fun get(context: Context): DownloadRepository =
            instance ?: synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }

        private fun build(appContext: Context): DownloadRepository {
            val client = OkHttpClient.Builder()
                .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            return DownloadRepository(
                context = appContext,
                dao = AppDatabase.get(appContext).downloadDao(),
                registry = ProviderRegistry(client),
                engine = DownloadEngine(client),
                storage = StorageManager(appContext),
                settings = SettingsStore(appContext)
            )
        }
    }

    // ---- Observation -------------------------------------------------------

    fun observeAll(): Flow<List<DownloadItem>> = dao.observeAll()
    fun observeActive(): Flow<List<DownloadItem>> = dao.observeActive()
    fun observeCompleted(): Flow<List<DownloadItem>> = dao.observeCompleted()
    fun observeFailed(): Flow<List<DownloadItem>> = dao.observeFailed()
    fun observeRecent(limit: Int = 5): Flow<List<DownloadItem>> = dao.observeRecent(limit)

    suspend fun findById(id: Long): DownloadItem? = dao.findById(id)
    suspend fun activeCount(): Int = dao.activeCount()

    /** Ids of everything waiting to run, oldest first. */
    suspend fun pendingIds(): List<Long> = dao.activeItems().map { it.id }

    /** The user's simultaneous-download limit. */
    suspend fun maxParallel(): Int = settings.settings.first().maxParallel

    // ---- Resolve -----------------------------------------------------------

    /** Asks the right provider what this link offers. Never invents formats. */
    suspend fun resolve(url: String): ResolveResult = registry.resolve(url)

    fun platformFor(url: String): Platform = registry.platformFor(url)

    // ---- Queue -------------------------------------------------------------

    /**
     * Creates a download row for [format] and returns its id, or null when the
     * link is already in the list (duplicate protection).
     */
    suspend fun enqueue(
        sourceUrl: String,
        title: String,
        format: MediaFormat,
        thumbnailUrl: String? = null
    ): Long? {
        if (dao.findExisting(sourceUrl) != null) return null

        val platform = registry.platformFor(sourceUrl)
        val fileName = UrlUtils.fileNameFrom(format.url, format.container)

        val item = DownloadItem(
            sourceUrl = sourceUrl,
            platformId = platform.id,
            title = title.ifBlank { fileName },
            kind = format.kind.name,
            formatLabel = format.label,
            container = format.container,
            mediaUrl = format.url,
            fileName = fileName,
            totalBytes = format.sizeBytes ?: 0L,
            status = DownloadStatus.QUEUED.name,
            thumbnailUrl = thumbnailUrl
        )
        return dao.insert(item)
    }

    // ---- Transfer ----------------------------------------------------------

    /**
     * Runs one download to completion. Called by the foreground service.
     *
     * @param onProgress live numbers, for the notification and the overlay.
     */
    suspend fun run(
        id: Long,
        onProgress: (DownloadProgress) -> Unit
    ) {
        val item = dao.findById(id) ?: return
        val kind = MediaKind.fromName(item.kind)

        val working = storage.workingFile(item.fileName)
        val resumeFrom = if (working.exists()) working.length() else 0L

        val prefs = settings.settings.first()

        if (item.totalBytes > 0L && !storage.hasSpaceFor(item.totalBytes - resumeFrom)) {
            markFailed(id, "error_no_storage")
            return
        }

        markStatus(id, DownloadStatus.DOWNLOADING)

        try {
            engine.download(
                url = item.mediaUrl,
                target = working,
                startOffset = resumeFrom,
                knownTotalBytes = item.totalBytes.takeIf { it > 0L },
                allowSegmented = prefs.segmented,
                onProgress = { progress ->
                    onProgress(progress)
                    // Persist progress sparsely: the UI reads it from memory while
                    // running, and from the database after a restart.
                    if (progress.downloadedBytes % (512L * 1024L) < 64L * 1024L) {
                        persistProgress(id, progress)
                    }
                }
            )

            val published = storage.publish(working, item.fileName, kind, prefs.downloadFolder)
            if (published == null) {
                // The transfer finished but the file could not be published.
                // Say so instead of reporting a success the user cannot find.
                markFailed(id, "error_permission_denied")
                return
            }

            val finalSize = if (working.exists()) working.length() else item.totalBytes
            dao.update(
                item.copy(
                    status = DownloadStatus.COMPLETED.name,
                    downloadedBytes = if (finalSize > 0L) finalSize else item.downloadedBytes,
                    totalBytes = if (item.totalBytes > 0L) item.totalBytes else finalSize,
                    contentUri = published,
                    filePath = published,
                    completedAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    errorCode = null,
                    errorMessage = null
                )
            )
        } catch (e: DownloadException) {
            markFailed(id, e.errorCode)
        } catch (e: kotlinx.coroutines.CancellationException) {
            markStatus(id, DownloadStatus.PAUSED)
            throw e
        } catch (e: Exception) {
            markFailed(id, "error_interrupted")
        }
    }

    private suspend fun persistProgress(id: Long, progress: DownloadProgress) {
        val item = dao.findById(id) ?: return
        dao.update(
            item.copy(
                downloadedBytes = progress.downloadedBytes,
                totalBytes = if (progress.totalBytes > 0L) progress.totalBytes else item.totalBytes,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun markStatus(id: Long, status: DownloadStatus) {
        val item = dao.findById(id) ?: return
        dao.update(item.copy(status = status.name, updatedAt = System.currentTimeMillis()))
    }

    suspend fun markFailed(id: Long, errorCode: String) {
        val item = dao.findById(id) ?: return
        dao.update(
            item.copy(
                status = DownloadStatus.FAILED.name,
                errorCode = errorCode,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    // ---- Management --------------------------------------------------------

    suspend fun pause(id: Long) = markStatus(id, DownloadStatus.PAUSED)

    suspend fun resume(id: Long) = markStatus(id, DownloadStatus.QUEUED)

    suspend fun cancel(id: Long) {
        val item = dao.findById(id) ?: return
        storage.workingFile(item.fileName).delete()
        markStatus(id, DownloadStatus.CANCELLED)
    }

    suspend fun retry(id: Long) {
        val item = dao.findById(id) ?: return
        storage.workingFile(item.fileName).delete()
        dao.update(
            item.copy(
                status = DownloadStatus.QUEUED.name,
                downloadedBytes = 0L,
                errorCode = null,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /** Removes the row and, when asked, the file it produced. */
    suspend fun delete(id: Long, deleteFile: Boolean) {
        val item = dao.findById(id) ?: return
        if (deleteFile) {
            storage.workingFile(item.fileName).delete()
            item.contentUri?.let { uri ->
                runCatching {
                    context.contentResolver.delete(android.net.Uri.parse(uri), null, null)
                }
            }
        }
        dao.deleteById(id)
    }

    suspend fun clearFinished() = dao.clearFinished()

    /** The file a finished download produced, if it still exists. */
    fun fileFor(item: DownloadItem): File? {
        val path = item.filePath ?: return null
        if (path.startsWith("content://")) return null
        val file = File(path)
        return if (file.exists()) file else null
    }
}
