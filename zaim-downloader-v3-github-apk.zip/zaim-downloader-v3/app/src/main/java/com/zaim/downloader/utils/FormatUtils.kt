package com.zaim.downloader.utils

import java.util.Locale
import java.util.concurrent.TimeUnit

/** Human-readable formatting for sizes, speeds and durations. */
object FormatUtils {

    fun bytes(value: Long): String {
        if (value <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var size = value.toDouble()
        var index = 0
        while (size >= 1024.0 && index < units.lastIndex) {
            size /= 1024.0
            index++
        }
        return if (index == 0) {
            "${size.toLong()} ${units[index]}"
        } else {
            String.format(Locale.US, "%.2f %s", size, units[index])
        }
    }

    /** Always KB/s or MB/s, as the brief requires. */
    fun speed(bytesPerSecond: Long): String {
        if (bytesPerSecond <= 0L) return "0 KB/s"
        val kb = bytesPerSecond / 1024.0
        return if (kb >= 1024.0) {
            String.format(Locale.US, "%.2f MB/s", kb / 1024.0)
        } else {
            String.format(Locale.US, "%.0f KB/s", kb)
        }
    }

    fun duration(millis: Long): String {
        if (millis <= 0L) return "--:--"
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(millis)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun date(epochMillis: Long): String {
        val format = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        return format.format(java.util.Date(epochMillis))
    }

    /** Estimated time left, or null when it cannot be computed honestly. */
    fun remaining(totalBytes: Long, downloadedBytes: Long, bytesPerSecond: Long): Long? {
        if (totalBytes <= 0L || bytesPerSecond <= 0L) return null
        val left = totalBytes - downloadedBytes
        if (left <= 0L) return 0L
        return (left * 1000L) / bytesPerSecond
    }
}
