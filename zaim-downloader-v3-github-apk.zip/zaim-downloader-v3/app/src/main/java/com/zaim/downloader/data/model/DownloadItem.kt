package com.zaim.downloader.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row of download history. Everything the UI needs to render a card and
 * everything the engine needs to resume a transfer lives here.
 */
@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,

    /** The link the user shared or pasted. */
    val sourceUrl: String,
    val platformId: String,
    val title: String,

    /** [MediaKind] name. */
    val kind: String,
    val formatLabel: String,
    val container: String,

    /** Direct media URL actually fetched. */
    val mediaUrl: String,
    val fileName: String,

    /** Absolute path once the file exists on disk. */
    val filePath: String? = null,

    /** MediaStore URI for a finished file in the public collection. */
    val contentUri: String? = null,

    val totalBytes: Long = 0L,
    val downloadedBytes: Long = 0L,

    /** [DownloadStatus] name. */
    val status: String = DownloadStatus.QUEUED.name,

    /** A string resource name such as "error_private_video". */
    val errorCode: String? = null,
    val errorMessage: String? = null,

    val thumbnailUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,

    /** True when the server answered with Accept-Ranges: bytes. */
    val supportsRanges: Boolean = false,
    val segments: Int = 1
) {
    val statusEnum: DownloadStatus get() = DownloadStatus.fromName(status)
    val kindEnum: MediaKind get() = MediaKind.fromName(kind)
    val platform: Platform get() = Platform.fromId(platformId)

    val progress: Float
        get() = if (totalBytes > 0L) (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f

    val progressPercent: Int get() = (progress * 100f).toInt()
}
