package com.zaim.downloader

import android.app.Application
import com.zaim.downloader.notifications.NotificationHelper

/**
 * Application entry point.
 *
 * Its only job is to make sure the notification channels exist before anything
 * tries to post to them.
 */
class ZaimApp : Application() {

    override fun onCreate() {
        super.onCreate()
        NotificationHelper(this).ensureChannels()
    }
}
