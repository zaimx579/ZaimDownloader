package com.zaim.downloader.download

import com.zaim.downloader.utils.FormatUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext

/** Live numbers the UI and the notification read while a transfer runs. */
data class DownloadProgress(
    val downloadedBytes: Long,
    val totalBytes: Long,
    val bytesPerSecond: Long,
    val segments: Int
) {
    val percent: Int
        get() = if (totalBytes > 0L) ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100) else 0

    val speedText: String get() = FormatUtils.speed(bytesPerSecond)
    val remainingText: String
        get() = FormatUtils.remaining(totalBytes, downloadedBytes, bytesPerSecond)?.let(FormatUtils::duration) ?: "--:--"
}

/** Raised when a transfer cannot continue; carries a string-resource error code. */
class DownloadException(val errorCode: String, message: String? = null, cause: Throwable? = null) :
    Exception(message, cause)

/**
 * The transfer engine.
 *
 * Design notes:
 * • Streams to disk through a [RandomAccessFile] so a paused transfer resumes
 *   from the exact byte it stopped at, using an HTTP Range request.
 * • When the server advertises `Accept-Ranges: bytes` and the file is large
 *   enough, it splits the file into N segments and fetches them in parallel,
 *   each writing into its own region of the same file. If anything about the
 *   server makes that unsafe, it falls back to a single stream — it never
 *   silently produces a corrupt file.
 * • Retries transient network failures with backoff, and reports a precise
 *   error code for everything else.
 */
class DownloadEngine(private val client: OkHttpClient) {

    companion object {
        /** Below this size, parallel segments cost more than they save. */
        private const val MIN_SEGMENTED_BYTES = 4L * 1024L * 1024L
        private const val MAX_SEGMENTS = 4
        private const val BUFFER_SIZE = 64 * 1024
        private const val MAX_RETRIES = 3
    }

    /**
     * Downloads [url] into [target].
     *
     * @param startOffset byte to resume from (0 for a fresh download).
     * @param knownTotalBytes total size if already known, else null.
     * @param allowSegmented whether the user enabled parallel segmented download.
     * @param onProgress called on every buffer flush with live numbers.
     * @return the number of bytes written in this run.
     */
    suspend fun download(
        url: String,
        target: File,
        startOffset: Long = 0L,
        knownTotalBytes: Long? = null,
        allowSegmented: Boolean = true,
        onProgress: (DownloadProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {

        target.parentFile?.mkdirs()

        // Probe the server once: real size, range support, and whether the link
        // is still alive. Everything downstream depends on these facts.
        val probe = probe(url, startOffset)
        val totalBytes = probe.totalBytes ?: knownTotalBytes ?: 0L

        val canSegment = allowSegmented &&
            probe.supportsRanges &&
            totalBytes >= MIN_SEGMENTED_BYTES &&
            startOffset == 0L

        if (canSegment) {
            val segments = decideSegmentCount(totalBytes)
            try {
                return@withContext segmentedDownload(url, target, totalBytes, segments, onProgress)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // A segmented attempt that fails must not leave a half-written
                // file behind: restart cleanly as a single stream.
                target.delete()
            }
        }

        singleStreamDownload(url, target, startOffset, totalBytes, onProgress)
    }

    private data class Probe(
        val totalBytes: Long?,
        val supportsRanges: Boolean,
        val contentLength: Long?
    )

    private fun probe(url: String, startOffset: Long): Probe {
        val request = Request.Builder()
            .url(url)
            .apply { if (startOffset > 0L) header("Range", "bytes=$startOffset-") }
            .build()

        val response = try {
            client.newCall(request).execute()
        } catch (e: UnknownHostException) {
            throw DownloadException("error_no_network", cause = e)
        } catch (e: SocketTimeoutException) {
            throw DownloadException("error_server_unavailable", cause = e)
        } catch (e: IOException) {
            throw DownloadException("error_server_unavailable", cause = e)
        }

        response.use { r ->
            if (!r.isSuccessful) {
                throw when (r.code) {
                    401, 403 -> DownloadException("error_protected_media")
                    404, 410 -> DownloadException("error_expired_link")
                    in 500..599 -> DownloadException("error_server_unavailable")
                    else -> DownloadException("error_unsupported_format")
                }
            }

            val ranges = r.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
            val contentRange = r.header("Content-Range")
            val total = when {
                contentRange != null -> contentRange.substringAfterLast('/').toLongOrNull()
                else -> r.body?.contentLength()?.takeIf { it > 0L }
            }
            return Probe(totalBytes = total, supportsRanges = ranges, contentLength = total)
        }
    }

    private fun decideSegmentCount(totalBytes: Long): Int {
        val bySize = (totalBytes / MIN_SEGMENTED_BYTES).toInt() + 1
        return bySize.coerceIn(2, MAX_SEGMENTS)
    }

    /** One connection, resumable, with retry. */
    private suspend fun singleStreamDownload(
        url: String,
        target: File,
        startOffset: Long,
        totalBytes: Long,
        onProgress: (DownloadProgress) -> Unit
    ): Long {
        var attempt = 0
        var offset = startOffset
        val counter = AtomicLong(offset)
        val meter = SpeedMeter()

        while (true) {
            coroutineContext.ensureActive()
            try {
                val request = Request.Builder()
                    .url(url)
                    .apply { if (offset > 0L) header("Range", "bytes=$offset-") }
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw when (response.code) {
                            401, 403 -> DownloadException("error_protected_media")
                            404, 410 -> DownloadException("error_expired_link")
                            in 500..599 -> DownloadException("error_server_unavailable")
                            else -> DownloadException("error_unsupported_format")
                        }
                    }

                    val body = response.body ?: throw DownloadException("error_unsupported_format")
                    val effectiveTotal = if (totalBytes > 0L) totalBytes else body.contentLength().coerceAtLeast(0L)

                    RandomAccessFile(target, "rw").use { raf ->
                        raf.seek(offset)
                        body.byteStream().use { input ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            while (true) {
                                coroutineContext.ensureActive()
                                val read = input.read(buffer)
                                if (read == -1) break
                                raf.write(buffer, 0, read)
                                val written = counter.addAndGet(read.toLong())
                                meter.record(read.toLong())
                                onProgress(
                                    DownloadProgress(
                                        downloadedBytes = written,
                                        totalBytes = effectiveTotal,
                                        bytesPerSecond = meter.bytesPerSecond(),
                                        segments = 1
                                    )
                                )
                            }
                        }
                    }
                    return counter.get() - startOffset
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: DownloadException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt > MAX_RETRIES) {
                    throw DownloadException("error_interrupted", cause = e)
                }
                // Resume from wherever the file actually got to.
                offset = if (target.exists()) target.length() else offset
                counter.set(offset)
                delay(backoffMillis(attempt))
            }
        }
    }

    /** N connections, each owning a byte range of the same file. */
    private suspend fun segmentedDownload(
        url: String,
        target: File,
        totalBytes: Long,
        segments: Int,
        onProgress: (DownloadProgress) -> Unit
    ): Long = coroutineScope {
        val counter = AtomicLong(0L)
        val meter = SpeedMeter()
        val chunk = totalBytes / segments

        // Pre-allocate so every segment can seek to its own offset.
        RandomAccessFile(target, "rw").use { it.setLength(totalBytes) }

        val jobs = (0 until segments).map { index ->
            val start = index * chunk
            val end = if (index == segments - 1) totalBytes - 1 else (start + chunk - 1)
            async(Dispatchers.IO) {
                fetchRange(url, target, start, end, counter, meter, totalBytes, segments, onProgress)
            }
        }
        jobs.awaitAll()
        counter.get()
    }

    private suspend fun fetchRange(
        url: String,
        target: File,
        start: Long,
        end: Long,
        counter: AtomicLong,
        meter: SpeedMeter,
        totalBytes: Long,
        segments: Int,
        onProgress: (DownloadProgress) -> Unit
    ) {
        var attempt = 0
        var from = start

        while (from <= end) {
            coroutineContext.ensureActive()
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("Range", "bytes=$from-$end")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.code != 206 && response.code != 200) {
                        throw DownloadException("error_server_unavailable")
                    }
                    val body = response.body ?: throw DownloadException("error_unsupported_format")

                    RandomAccessFile(target, "rw").use { raf ->
                        raf.seek(from)
                        body.byteStream().use { input ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            while (from <= end) {
                                coroutineContext.ensureActive()
                                val max = minOf(buffer.size.toLong(), end - from + 1).toInt()
                                val read = input.read(buffer, 0, max)
                                if (read == -1) break
                                raf.write(buffer, 0, read)
                                from += read
                                val written = counter.addAndGet(read.toLong())
                                meter.record(read.toLong())
                                onProgress(
                                    DownloadProgress(
                                        downloadedBytes = written,
                                        totalBytes = totalBytes,
                                        bytesPerSecond = meter.bytesPerSecond(),
                                        segments = segments
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: DownloadException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt > MAX_RETRIES) throw DownloadException("error_interrupted", cause = e)
                delay(backoffMillis(attempt))
            }
        }
    }

    private fun backoffMillis(attempt: Int): Long = (500L * (1L shl (attempt - 1))).coerceAtMost(8_000L)
}

/**
 * Rolling speed meter. Averages over a short window so the number on screen is
 * steady rather than jumping with every buffer.
 */
internal class SpeedMeter(private val windowMillis: Long = 1_500L) {
    private var windowStart = System.currentTimeMillis()
    private var windowBytes = 0L
    private var lastRate = 0L

    @Synchronized
    fun record(bytes: Long) {
        windowBytes += bytes
        val now = System.currentTimeMillis()
        val elapsed = now - windowStart
        if (elapsed >= windowMillis) {
            lastRate = (windowBytes * 1000L) / elapsed
            windowBytes = 0L
            windowStart = now
        }
    }

    @Synchronized
    fun bytesPerSecond(): Long = lastRate
}
