package com.zaim.downloader.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaim.downloader.R
import com.zaim.downloader.data.model.DownloadItem
import com.zaim.downloader.data.model.DownloadStatus
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.components.EmptyState
import com.zaim.downloader.ui.components.Pill
import com.zaim.downloader.ui.components.ZaimCard
import com.zaim.downloader.ui.theme.ZaimError
import com.zaim.downloader.ui.theme.ZaimGold
import com.zaim.downloader.ui.theme.ZaimSuccess
import com.zaim.downloader.utils.FormatUtils
import java.io.File

/**
 * The download manager: active, completed and failed, with the full set of
 * actions (pause, resume, cancel, retry, open, share, delete).
 */
@Composable
fun DownloadsScreen(viewModel: AppViewModel) {
    val active by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val completed by viewModel.completedDownloads.collectAsStateWithLifecycle()
    val failed by viewModel.failedDownloads.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pendingDelete by remember { mutableStateOf<DownloadItem?>(null) }

    val tabs = listOf(
        stringResource(R.string.downloads_active) to active,
        stringResource(R.string.downloads_completed) to completed,
        stringResource(R.string.downloads_failed) to failed
    )

    Column(Modifier.fillMaxSize()) {
        Text(
            text = stringResource(R.string.downloads_title),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp)
        )

        TabRow(
            selectedTabIndex = tab,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = ZaimGold
        ) {
            tabs.forEachIndexed { index, (label, list) ->
                Tab(
                    selected = tab == index,
                    onClick = { tab = index },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(label)
                            if (list.isNotEmpty()) {
                                Spacer(Modifier.width(6.dp))
                                Pill(text = list.size.toString())
                            }
                        }
                    }
                )
            }
        }

        val current = tabs[tab].second

        if (current.isEmpty()) {
            EmptyState(
                icon = Icons.Rounded.Download,
                title = stringResource(R.string.downloads_empty),
                hint = stringResource(R.string.downloads_empty_hint)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(current, key = { it.id }) { item ->
                    DownloadCard(
                        item = item,
                        onPause = { viewModel.pause(item.id) },
                        onResume = { viewModel.resume(item.id) },
                        onCancel = { viewModel.cancel(item.id) },
                        onRetry = { viewModel.retry(item.id) },
                        onDelete = { pendingDelete = item }
                    )
                }
            }
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.action_delete)) },
            text = { Text(item.title) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.delete(item.id, deleteFile = true)
                    pendingDelete = null
                }) { Text(stringResource(R.string.action_delete), color = ZaimError) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(stringResource(R.string.common_cancel))
                }
            }
        )
    }
}

/** One download card with live progress and its actions. */
@Composable
private fun DownloadCard(
    item: DownloadItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val status = item.statusEnum

    ZaimCard {
        Column {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = null,
                        tint = ZaimGold,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(Modifier.width(12.dp))

                Column(Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill(text = item.platform.displayName)
                        Pill(text = item.formatLabel)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            when (status) {
                DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED, DownloadStatus.ANALYZING -> {
                    LinearProgressIndicator(
                        progress = item.progress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = ZaimGold,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.progressPercent}% · ${FormatUtils.bytes(item.downloadedBytes)} / " +
                                FormatUtils.bytes(item.totalBytes),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = item.statusEnum.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall,
                            color = ZaimGold
                        )
                    }
                }

                DownloadStatus.PAUSED -> {
                    Text(
                        text = stringResource(R.string.action_pause) + " · ${item.progressPercent}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                DownloadStatus.COMPLETED -> {
                    Text(
                        text = "${FormatUtils.bytes(item.totalBytes)} · ${FormatUtils.date(item.createdAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZaimSuccess
                    )
                }

                DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                    val reason = item.errorCode?.let { code ->
                        runCatching {
                            context.getString(context.resources.getIdentifier(code, "string", context.packageName))
                        }.getOrDefault(code)
                    } ?: stringResource(R.string.error_interrupted)
                    Text(
                        text = reason,
                        style = MaterialTheme.typography.labelSmall,
                        color = ZaimError
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                when (status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED, DownloadStatus.ANALYZING -> {
                        IconButton(onClick = onPause) {
                            Icon(Icons.Rounded.Pause, stringResource(R.string.action_pause), tint = ZaimGold)
                        }
                        IconButton(onClick = onCancel) {
                            Icon(Icons.Rounded.Cancel, stringResource(R.string.action_cancel), tint = ZaimError)
                        }
                    }

                    DownloadStatus.PAUSED -> {
                        IconButton(onClick = onResume) {
                            Icon(Icons.Rounded.PlayArrow, stringResource(R.string.action_resume), tint = ZaimGold)
                        }
                        IconButton(onClick = onCancel) {
                            Icon(Icons.Rounded.Cancel, stringResource(R.string.action_cancel), tint = ZaimError)
                        }
                    }

                    DownloadStatus.COMPLETED -> {
                        IconButton(onClick = { openItem(context, item) }) {
                            Icon(Icons.Rounded.OpenInNew, stringResource(R.string.action_open), tint = ZaimGold)
                        }
                        IconButton(onClick = { shareItem(context, item) }) {
                            Icon(Icons.Rounded.Share, stringResource(R.string.action_share), tint = ZaimGold)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Rounded.Delete, stringResource(R.string.action_delete), tint = ZaimError)
                        }
                    }

                    DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                        IconButton(onClick = onRetry) {
                            Icon(Icons.Rounded.Refresh, stringResource(R.string.action_retry), tint = ZaimGold)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Rounded.Delete, stringResource(R.string.action_delete), tint = ZaimError)
                        }
                    }
                }
            }
        }
    }
}

/** Opens a finished file with whatever app the user has for it. */
private fun openItem(context: android.content.Context, item: DownloadItem) {
    val uri = item.contentUri?.let(Uri::parse) ?: item.filePath?.let { path ->
        val file = File(path)
        if (!file.exists()) return
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    } ?: return

    val mime = if (item.kindEnum.name == "AUDIO") "audio/*" else "video/*"
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
}

/** Shares a finished file through the system Sharesheet. */
private fun shareItem(context: android.content.Context, item: DownloadItem) {
    val uri = item.contentUri?.let(Uri::parse) ?: item.filePath?.let { path ->
        val file = File(path)
        if (!file.exists()) return
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    } ?: return

    val mime = if (item.kindEnum.name == "AUDIO") "audio/*" else "video/*"
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching {
        context.startActivity(Intent.createChooser(intent, item.title))
    }
}
