package com.zaim.downloader.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaim.downloader.R
import com.zaim.downloader.data.model.MediaFormat
import com.zaim.downloader.ui.AnalyzeState
import com.zaim.downloader.ui.AppViewModel
import com.zaim.downloader.ui.components.Pill
import com.zaim.downloader.ui.components.ZaimCard
import com.zaim.downloader.ui.theme.ZaimError
import com.zaim.downloader.ui.theme.ZaimGold
import com.zaim.downloader.utils.FormatUtils

/**
 * The format picker.
 *
 * It shows exactly what the source offers — nothing invented. When a source has
 * no authorised download method, it says so plainly and points at the
 * platform's own option instead of pretending to work.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzeSheet(viewModel: AppViewModel) {
    val state by viewModel.analyze.collectAsStateWithLifecycle()
    if (state is AnalyzeState.Idle) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    ModalBottomSheet(
        onDismissRequest = { viewModel.dismissAnalyze() },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            when (val current = state) {
                is AnalyzeState.Loading -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = ZaimGold,
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = stringResource(R.string.analyze_loading),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                is AnalyzeState.Failure -> {
                    Text(
                        text = stringResource(R.string.analyze_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(14.dp))

                    val errorRes = current.result.failure?.errorCode
                        ?.let { context.resources.getIdentifier(it, "string", context.packageName) }
                        ?: R.string.error_unsupported_url

                    ZaimCard {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = null,
                                tint = ZaimError,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = stringResource(errorRes),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                current.result.note?.let { note ->
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = note,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { viewModel.dismissAnalyze() }) {
                        Text(stringResource(R.string.action_close), color = ZaimGold)
                    }
                }

                is AnalyzeState.Success -> {
                    Text(
                        text = current.result.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = current.url,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )

                    current.result.note?.let { note ->
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = note,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.height(18.dp))

                    val videos = current.result.formats.filter { it.isVideo }
                    val audios = current.result.formats.filterNot { it.isVideo }

                    if (videos.isNotEmpty()) {
                        Text(
                            text = stringResource(R.string.analyze_video_section),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        videos.forEach { format ->
                            FormatRow(
                                format = format,
                                onSelect = {
                                    viewModel.startDownload(
                                        current.url,
                                        current.result.title,
                                        format,
                                        current.result.thumbnailUrl
                                    )
                                }
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    if (audios.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = stringResource(R.string.analyze_audio_section),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        audios.forEach { format ->
                            FormatRow(
                                format = format,
                                onSelect = {
                                    viewModel.startDownload(
                                        current.url,
                                        current.result.title,
                                        format,
                                        current.result.thumbnailUrl
                                    )
                                }
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                AnalyzeState.Idle -> Unit
            }
        }
    }
}

/** One selectable format row. */
@Composable
private fun FormatRow(format: MediaFormat, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onSelect)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (format.isVideo) Icons.Rounded.Videocam else Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = ZaimGold,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = format.summary,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = format.sizeBytes?.let(FormatUtils::bytes)
                    ?: stringResource(R.string.analyze_size_unknown),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.Rounded.Download,
            contentDescription = stringResource(R.string.analyze_start),
            tint = ZaimGold,
            modifier = Modifier.size(20.dp)
        )
    }
}
