# دليل بناء ZAIM Downloader — من الكود إلى APK

**تم التطوير بواسطة شركة ZAIM X تحت إشراف المهندس أحمد أشرف سعيد السعدني**

---

## ⚠️ اقرأ هذا أولًا

لم يُبنَ ملف APK في بيئة العمل التي أُعدّ فيها المشروع، **لأن بناء حزم الهواتف محجوب في تلك البيئة** — لا يوجد هاتف ولا محاكي للاختبار، والحزم المبنية بهذه الطريقة فشلت مرارًا في التثبيت عند المستخدمين.

لذلك سلّمتُك **الكود المصدري الكامل** + **طريقتين** للحصول على APK:

| الطريقة | ما تحتاجه | الزمن | الناتج |
|---|---|---|---|
| **أ) GitHub Actions** (الأسهل) | حساب GitHub مجاني | ~10 دقائق | APK جاهز للتنزيل |
| **ب) Android Studio** | جهاز بذاكرة 8GB+ | ~20 دقيقة | APK على جهازك |

**الطريقة (أ) لا تحتاج تثبيت أي شيء على جهازك** — GitHub يبني الـ APK في السحابة ويعطيك الملف.

---

## الطريقة (أ): البناء السحابي عبر GitHub Actions ⭐

المشروع يحتوي على سير عمل جاهز في `.github/workflows/build-apk.yml` يبني APK موقّعًا تلقائيًا.

### الخطوات

**1. أنشئ مستودعًا جديدًا على GitHub**
- اذهب إلى https://github.com/new
- الاسم: `zaim-downloader` (أو أي اسم)
- اجعله **Private** إن أردت
- اضغط **Create repository**

**2. ارفع المشروع**
- فك ضغط `zaim-downloader-v3.zip`
- في صفحة المستودع اضغط **uploading an existing file**
- اسحب **كل محتويات** المجلد المفكوك (بما فيها مجلد `.github` المخفي)
- اضغط **Commit changes**

> **مهم:** مجلد `.github` مخفي في بعض أنظمة الملفات. تأكد من رفعه، وإلا لن يعمل سير العمل.
> بديل أسهل: استخدم GitHub Desktop أو `git push` من الطرفية.

**3. شغّل البناء**
- في المستودع اذهب إلى تبويب **Actions**
- اختر **Build ZAIM Downloader APK** من القائمة اليسرى
- اضغط **Run workflow** ← **Run workflow**

**4. نزّل الـ APK**
- انتظر ~5–8 دقائق (سترى علامة ✓ خضراء)
- افتح تشغيل البناء الناجح
- في الأسفل، قسم **Artifacts** ← نزّل **zaim-downloader-apk**
- داخله ملف `.apk` — انقله إلى هاتفك وثبّته

**5. ثبّت على الهاتف**
- انقل ملف الـ APK إلى الهاتف (كابل، أو Google Drive، أو أرسله لنفسك)
- افتحه من مدير الملفات
- إن ظهر تحذير: **الإعدادات ← الأمان ← تثبيت تطبيقات غير معروفة** ← اسمح للمتصفح/مدير الملفات
- اضغط **تثبيت**

> سير العمل يوقّع الـ APK بمفتاح التطوير تلقائيًا، ويطبع نتائج `apksigner verify` و`aapt2 badging` و`zipalign` و`SHA-256` في سجل البناء.

---

## الطريقة (ب): البناء المحلي عبر Android Studio

### المتطلبات

| المكوّن | الإصدار | ملاحظة |
|---|---|---|
| **JDK** | 17 | مطلوب — لا يعمل مع 11 أو 21 |
| **Android Studio** | Ladybug (2024.2) أو أحدث | يأتي مع Android SDK |
| **Android SDK** | Platform 34 + Build-Tools 34.0.0 | يُنزّلها Android Studio |
| **ذاكرة RAM** | 8 GB مستحسنة | الإعدادات مضبوطة لتعمل على 2 GB أيضًا |
| **مساحة قرص** | ~5 GB | لـ Gradle والاعتماديات |

### الخطوات

**1. افتح المشروع**
- فك ضغط `zaim-downloader-v3.zip`
- Android Studio ← **Open** ← اختر **مجلد المشروع** (الذي يحتوي `settings.gradle.kts`)
- **لا** تفتح مجلد `app` مباشرة

**2. انتظر Gradle Sync**
- سيُنزّل Gradle 8.7 والاعتماديات (~3–5 دقائق في المرة الأولى)
- انتظر حتى تختفي شريط التقدّم السفلي

**3. ابنِ الـ APK**

من الطرفية داخل مجلد المشروع:
```bash
./gradlew assembleRelease
```

أو من الواجهة: **Build ← Build App Bundle(s) / APK(s) ← Build APK(s)**

**4. الناتج**
```
app/build/outputs/apk/release/app-release.apk
```

**5. وقّع الـ APK بمفتاحك الخاص (مستحسن للنشر)**

المشروع يوقّع بمفتاح التطوير تلقائيًا إن لم يوجد مفتاح خاص. لإنشاء مفتاحك:

```bash
keytool -genkeypair -v \
  -keystore zaim-release.jks \
  -alias zaim \
  -keyalg RSA -keysize 2048 -validity 10000
```

ثم أنشئ ملف `keystore.properties` في **جذر المشروع**:
```properties
storeFile=zaim-release.jks
storePassword=كلمة_المرور_التي_اخترتها
keyAlias=zaim
keyPassword=كلمة_المرور_التي_اخترتها
```

أعد البناء — سيستخدم المشروع مفتاحك تلقائيًا.

> ⚠️ **احتفظ بملف `zaim-release.jks` وكلمات المرور في مكان آمن.** فقدانه يعني عدم قدرتك على تحديث التطبيق على Google Play أبدًا.

**6. تحقّق من الـ APK**

```bash
# مسار أدوات البناء (عدّله حسب إصدار SDK لديك)
BT="$ANDROID_HOME/build-tools/34.0.0"

# 1) التحقق من التوقيع
"$BT/apksigner" verify --print-certs app/build/outputs/apk/release/app-release.apk

# 2) معلومات الحزمة
"$BT/aapt2" dump badging app/build/outputs/apk/release/app-release.apk | head -20

# 3) محاذاة ZIP
"$BT/zipalign" -c 4 app/build/outputs/apk/release/app-release.apk

# 4) البصمة
sha256sum app/build/outputs/apk/release/app-release.apk
```

---

## إعدادات الذاكرة (مهمة للأجهزة الصغيرة)

ملف `gradle.properties` مضبوط مسبقًا لبيئة 2 جيجابايت:

```properties
org.gradle.jvmargs=-Xmx768m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC -Dfile.encoding=UTF-8
org.gradle.parallel=false
org.gradle.workers.max=1
kotlin.compiler.execution.strategy=in-process
```

**لماذا `in-process`؟** افتراضيًا يشغّل Kotlin مُجمّعًا منفصلًا (JVM ثانية) بجانب JVM الخاص بـ Gradle. على جهاز بذاكرة صغيرة يتجمّد البناء عند سقف الذاكرة. `in-process` يجعل المُجمّع يعمل داخل نفس الـ JVM.

### 🔴 تحذير: لا تضبط `JAVA_TOOL_OPTIONS`

إن كان متغير البيئة `JAVA_TOOL_OPTIONS` مضبوطًا (مثلًا `-Xmx512m`)، فإنه **يُلحق فوق** `org.gradle.jvmargs` ويقتل الـ daemon بصمت. أزله:

```bash
unset JAVA_TOOL_OPTIONS
```

على جهاز بذاكرة 8 جيجابايت أو أكثر، يمكنك رفع القيم:
```properties
org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
org.gradle.parallel=true
org.gradle.workers.max=4
```

---

## حل المشاكل الشائعة

| الخطأ | السبب | الحل |
|---|---|---|
| `Unsupported class file major version` | JDK خاطئ | ثبّت JDK 17 واجعله `JAVA_HOME` |
| `SDK location not found` | لا يوجد `local.properties` | أنشئه: `sdk.dir=/path/to/Android/Sdk` |
| `Could not resolve androidx...` | لا اتصال بمستودعات Google | تحقق من الإنترنت/البروكسي |
| البناء يتجمّد بلا رسالة | نفاد الذاكرة | تأكد من `in-process` و`workers.max=1`، وأزل `JAVA_TOOL_OPTIONS` |
| `Execution failed for task ':app:processReleaseResources'` | تعارض موارد | نفّذ `./gradlew clean` ثم أعد البناء |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | نسخة قديمة بنفس الحزمة | أزل التطبيق القديم من الهاتف أولًا |
| `App not installed` | توقيع مختلف | أزل النسخة القديمة، أو استخدم نفس المفتاح |

---

## الأذونات التي يطلبها التطبيق

| الإذن | لماذا | متى يُطلب |
|---|---|---|
| `INTERNET` | تنزيل الملفات | تلقائي |
| `ACCESS_NETWORK_STATE` | معرفة حالة الشبكة | تلقائي |
| `SYSTEM_ALERT_WINDOW` | الدائرة العائمة | عند تفعيلها، مع شاشة شرح |
| `POST_NOTIFICATIONS` | إشعارات التقدّم | عند أول تشغيل (أندرويد 13+) |
| `FOREGROUND_SERVICE` | إكمال التنزيل في الخلفية | تلقائي |
| `WRITE_EXTERNAL_STORAGE` | حفظ الملف (أندرويد 9 وأقدم فقط) | عند أول تنزيل |

**لا يوجد إذن واحد أكثر من اللازم.** لا جهات اتصال، لا موقع، لا كاميرا، لا ميكروفون.

---

## ما يعمل وما لا يعمل — بصراحة

### ✅ يعمل فعليًا
- **الروابط المباشرة لملفات الوسائط** (`.mp4`, `.mp3`, `.m4a`, `.webm`, `.mkv`, `.mov`, `.aac`, `.ogg`, `.wav`, `.flac`)
  - يقرأ الحجم والنوع الحقيقيين من ترويسات الخادم
  - تنزيل مجزّأ متوازٍ حتى 4 أجزاء عند دعم `Accept-Ranges`
  - استئناف من البايت نفسه، 3 محاولات إعادة
- **الدائرة العائمة**: سحب، ضغطة للتنزيل، ضغطة مطوّلة للتصغير/الإغلاق، التصاق بالحافة
- **استقبال المشاركة** من أي تطبيق عبر Sharesheet
- **إدارة كاملة**: إيقاف، استئناف، إلغاء، إعادة، فتح، مشاركة، حذف
- **الحفظ** في `Downloads/ZAIM Downloader` عبر MediaStore
- **عربي/إنجليزي** مع RTL، وضع داكن/فاتح

### ❌ لا يعمل — والسبب تقني وقانوني
**YouTube · TikTok · Facebook · Instagram · X · Telegram · WhatsApp**

هذه المنصات **لا توفّر نقطة وصول عامة ومصرّحًا بها** لملف الفيديو. الوسائط تُسلَّم عبر:
- جلسة موثّقة (تسجيل دخول)
- روابط موقّعة تنتهي بسرعة
- حماية DRM

تجاوز ذلك يخالف شروط استخدامها وقوانين حقوق النشر. لذلك التطبيق **يخبرك بالسبب بدقة** ويوجّهك للخيار الرسمي، بدلًا من زر يفشل بصمت أو يدّعي نجاحًا وهميًا.

هذا السلوك في `providers/PlatformProvider.kt` — المكان الوحيد الذي يحتاج تعديلًا لو أصدرت منصة لاحقًا واجهة رسمية.

---

## بنية المشروع

```
zaim-downloader-v3/
├── .github/workflows/build-apk.yml   ← البناء السحابي
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/zaim/downloader/
│       │   ├── MainActivity.kt              ← النشاط الوحيد
│       │   ├── ShareReceiverActivity.kt     ← استقبال المشاركة
│       │   ├── ZaimApp.kt
│       │   ├── data/                        ← Room + DataStore
│       │   ├── download/                    ← المحرّك + الخدمة + المستودع
│       │   ├── overlay/                     ← الدائرة العائمة
│       │   ├── notifications/
│       │   ├── permissions/
│       │   ├── providers/                   ← موصلات المصادر
│       │   ├── storage/                     ← MediaStore
│       │   ├── ui/                          ← Compose
│       │   └── utils/
│       └── res/
│           ├── values/strings.xml           ← 124 نصًا إنجليزيًا
│           ├── values-ar/strings.xml        ← 124 نصًا عربيًا
│           ├── drawable/  mipmap-anydpi/  mipmap-anydpi-v26/
│           └── xml/
├── gradle/wrapper/                   ← Gradle 8.7
├── gradlew  gradlew.bat
├── build.gradle.kts  settings.gradle.kts  gradle.properties
└── BUILD_GUIDE_AR.md  README.md
```

---

## الأسئلة الشائعة

**س: هل التطبيق مجاني؟**
ج: نعم، بالكامل. لا اشتراكات، لا إعلانات، لا تتبّع.

**س: هل يرسل بياناتي لأي مكان؟**
ج: لا. كل شيء على جهازك. لا حساب، لا تسجيل دخول، لا تحليلات. سجل التنزيلات مستثنى من النسخ الاحتياطي السحابي.

**س: هل يمكن نشره على Google Play؟**
ج: نعم، لكن تحتاج **release keystore** خاصًا بك (الخطوة 5 أعلاه). مفتاح التطوير لا يصلح للنشر.

**س: لماذا حجم الـ APK صغير (~7 MB)؟**
ج: لا مكتبات ثقيلة. Compose + OkHttp + Room فقط.

**س: هل يعمل على أندرويد قديم؟**
ج: من أندرويد 7.0 (API 24) حتى 15 (API 35).

---

**تم التطوير بواسطة شركة ZAIM X تحت إشراف المهندس أحمد أشرف سعيد السعدني**
